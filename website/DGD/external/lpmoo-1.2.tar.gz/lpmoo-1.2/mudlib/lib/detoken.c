/*
 * NAME:	detoken.c
 * DESCRIPTION:	uncompress verb code
 */

# include <moo/tokens.h>

mapping tokmap;		/* map of all tokens */

/*
 * NAME:	create()
 * DESCRIPTION:	initialize data
 */
static
void create(void)
{
  tokmap = ([
    TOK_PERCENT   : " % ",
    TOK_QUESTION  : " ? ",
    TOK_PIPE      : " | ",
    TOK_MINUS     : " - ",
    TOK_PLUS      : " + ",
    TOK_ASSOC     : " ~ ",
    TOK_COMMA     : ", ",
    TOK_SEMICOLON : ";\n",
    TOK_RPAREN    : ")\n",
    TOK_RBRACKET  : "]\n",
    TOK_ASSIGN    : " = ",
    TOK_TIMES     : " * ",
    TOK_DIVIDE    : " / ",
    TOK_IF        : "if (",
    TOK_ELSEIF    : "elseif (",
    TOK_ELSE      : "else\n",
    TOK_ENDIF     : "endif\n",
    TOK_FOR       : "for ",
    TOK_IN        : " in ",
    TOK_ENDFOR    : "endfor\n",
    TOK_WHILE     : "while (",
    TOK_ENDWHILE  : "endwhile\n",
    TOK_FORK      : "fork ",
    TOK_ENDFORK   : "endfork\n",
    TOK_RETURN    : "return",
    TOK_RANGE     : "..",
    TOK_EQUAL     : " == ",
    TOK_NEQUAL    : " != ",
    TOK_LESS      : " < ",
    TOK_LSEQUAL   : " <= ",
    TOK_GREATER   : " > ",
    TOK_GREQUAL   : " >= ",
    TOK_AND       : " && ",
    TOK_OR        : " || ",

    VTOK_BUF      : "BUF",
    VTOK_ERR      : "ERR",
    VTOK_FLOAT    : "FLOAT",
    VTOK_LIST     : "LIST",
    VTOK_NUM      : "NUM",
    VTOK_OBJ      : "OBJ",
    VTOK_STR      : "STR",
    VTOK_TABLE    : "TABLE",

    VTOK_PLAYER   : "player",
    VTOK_THIS     : "this",
    VTOK_CALLER   : "caller",
    VTOK_ARGS     : "args",
    VTOK_ARGSTR   : "argstr",
    VTOK_VERB     : "verb",
    VTOK_DOBJ     : "dobj",
    VTOK_DOBJSTR  : "dobjstr",
    VTOK_PREPSTR  : "prepstr",
    VTOK_IOBJ     : "iobj",
    VTOK_IOBJSTR  : "iobjstr",
  ]);
}

/*
 * NAME:	main()
 * DESCRIPTION:	detokenize the given source code
 */
string main(string code, int full_paren, int do_indent)
{
  string subst, indent;
  int i, sz;

  if (do_indent)
    indent = "";

  for (i = 0, sz = strlen(code); i < sz; ++i)
    {
      int c;

      if (! ((c = code[i]) & 0x80))
	continue;

      switch (c &= ~0x80)
	{
	case 0x00:  /* magic indent */
	  subst = do_indent ? indent : "";
	  break;

	case 0x01:  /* magic --indent */
	  subst = do_indent ? (indent = indent[2 ..]) : "";
	  break;

	case 0x02:  /* magic ++indent */
	  subst = do_indent ? (indent += "  ") : "";
	  break;

	case '{':  /* magic paren */
	case '}':
	  if (! full_paren)
	    {
	      subst = "";
	      break;
	    }
	  code[i] = (c == '{' ? '(' : ')');
	  continue;

	default:
	  subst = tokmap[c];
	  if (subst == 0)
	    error("Unknown token in source: " + (string) c);
	}

      code = code[.. i - 1] + subst + code[i + 1 ..];
      c = strlen(subst) - 1;
      i += c, sz += c;
    }

  return code;
}
