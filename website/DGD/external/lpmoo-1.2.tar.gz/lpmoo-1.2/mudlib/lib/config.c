/*
 * NAME:	config.c
 * DESCRIPTION:	runtime configuration object
 */

# include <moo/config.h>
# include <dgd/limits.h>
# include <version.h>

mixed  *config;

# define TRUE	1
# define FALSE	0

# define YES	TRUE
# define NO	FALSE
# define NONE	FALSE

/*
 * NAME:	ports()
 * DESCRIPTION:	return the telnet and binary ports from DGD's config file
 */
private
int *ports(void)
{
  int		telnet_port;
  int		binary_port;
  string	directory;
  int		users;
  int		editors;
  string	ed_tmpfile;
  string	swap_file;
  int		swap_size;
  int		cache_size;
  int		sector_size;
  int		swap_fragment;
  int		static_chunk;
  int		dynamic_chunk;
  string	dump_file;
  int		typechecking;
  string	include_file;
  string       *include_dirs;
  string	auto_object;
  string	driver_object;
  string	create;
  int		value_stack;
  int		reserved_vstack;
  int		call_stack;
  int		reserved_cstack;
  int		max_cost;
  int		array_size;
  int		objects;
  int		call_outs;

# include "/etc/dgd.cf"

  return ({ telnet_port, binary_port });
}

/*
 * NAME:	create()
 * DESCRIPTION:	initialize the config object
 */
static
void create(void)
{
  int		eval_backdoor;

  string	oob_prefix;
  int		log_commands;

  int		fg_ticks;
  int		bg_ticks;
  int		fg_seconds;
  int		bg_seconds;

  int		outbound_net;
  int		mport_listening;
  int		server_msgs;

  int		connect_timeout;

  int		pattern_cache;
  int		verb_cache;

  int		max_verb_depth;
  int		stack_size;
  int		swap_interval;
  int		memory_thresh;

  string	timezone;

  string	bootstrap_file;
  string	checkpoint_file;
  string	log_file;

  string	huh_failed_msg;
  string       *prepositions;
  string       *protected_bfuns;

# include "/etc/moo.cf"

  config = ({ VERSION_MOO, VERSION_LPMOO }) + ports() +
    ({ eval_backdoor,

       oob_prefix,
       log_commands,

       fg_ticks,
       bg_ticks,
       fg_seconds,
       bg_seconds,

       outbound_net,
       mport_listening,
       server_msgs,

       connect_timeout,

       pattern_cache,
       verb_cache,

       max_verb_depth,
       stack_size,
       swap_interval,
       memory_thresh,

       timezone,

       bootstrap_file,
       checkpoint_file,
       log_file,

       huh_failed_msg,
       prepositions,
       protected_bfuns,

       MAX_EXEC_COST,
    });
}

/*
 * NAME:	query()
 * DESCRIPTION:	return a configuration value
 */
mixed query(int key)
{ return config[key]; }
