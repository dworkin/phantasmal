/*
 * NAME:	btable.c
 * DESCRIPTION:	builtin function table
 */

mapping funcs;			/* all builtins */

# define FUNCDEF(nonsimple, func, min, max)  \
  func : encode(nonsimple, min, max),

# define O_NONSIMPLE	0
# define O_MINARGS	1
# define O_MAXARGS	2

/*
 * NAME:	encode()
 * DESCRIPTION:	return a string encoding of the function information
 */
private
string encode(int nonsimple, int min, int max)
{
  string vector;

  vector = "xxx";
  vector[O_NONSIMPLE] = nonsimple;
  vector[O_MINARGS]   = min;
  vector[O_MAXARGS]   = max;

  return vector;
}

/*
 * NAME:	create()
 * DESCRIPTION:	initialize data
 */
static
void create(void)
{
  funcs = ([
# include "../std/bfuns/moofuns.c"
# include "../std/bfuns/dgdfuns.c"
# include "../std/bfuns/extrafuns.c"
	  ]);
}

/*
 * NAME:	btable->exists()
 * DESCRIPTION:	return 1 iff function exists
 */
int exists(string func)
{
  return funcs[func] != 0;
}

/*
 * NAME:	btable->simple()
 * DESCRIPTION:	return 1 iff function is simple
 */
int simple(string func)
{
  return ! funcs[func][O_NONSIMPLE];
}

/*
 * NAME:	btable->invokation()
 * DESCRIPTION:	return a function header for invoking the builtin
 */
string invokation(string func, int jsnum)
{
  return "b_" + func +
    (funcs[func][O_NONSIMPLE] ?
     "(JS_DATA(" + (string) jsnum + ")" : "(info");
}

/*
 * NAME:	btable->minargs()
 * DESCRIPTION:	return the minimum number of arguments for the function
 */
int minargs(string func)
{
  return funcs[func][O_MINARGS];
}

/*
 * NAME:	btable->maxargs()
 * DESCRIPTION:	return the maximum number of arguments for the function, or -1
 */
int maxargs(string func)
{
  int num;

  num = funcs[func][O_MAXARGS];
  return (num & 0x80) ? -1 : num;
}
