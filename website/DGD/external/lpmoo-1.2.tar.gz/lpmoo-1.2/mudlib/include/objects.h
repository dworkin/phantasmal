/*
 * NAME:	objects.h
 * DESCRIPTION:	name (path) of common objects
 */

# define DRIVER		"/lib/driver"

# define DNS		"/lib/dns"
# define LISTENER	"/obj/listener"

# define TELNET		"/obj/telnet"
# define BINARY		"/obj/binary"
# define OUTBOUND	"/obj/outbound"

# define OBJECT		"/obj/object"

# define PARSER		"/lib/parser"
# define UNPARSER	"/lib/unparser"
# define DETOKEN	"/lib/detoken"
# define COMPILER	"/lib/compiler"
# define OPTIMIZER	"/lib/optimizer"
# define LEXAN		"/std/lex"

# define GLOBAL		"/lib/global"
# define CONFIG		"/lib/config"

# define BTABLE		"/lib/btable"

# define DBLOADER	"/obj/dbloader"
# define DBSAVER	"/obj/dbsaver"
