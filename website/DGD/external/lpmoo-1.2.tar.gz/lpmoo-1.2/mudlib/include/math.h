/*
 * NAME:	math.h
 * DESCRIPTION:	useful math constants
 */

# define MACHEP		 1.11022302462515654042e-16	/* 2 ** -53 */
# define MAXLOG		 7.08396418532264106224e+2	/* log 2 ** 1022 */
# define MINLOG		-7.08396418532264106224e+2	/* log 2 ** -1022 */
# define MAXNUM		 1.7976931348623158e308		/* 2 ** 1024 *
							   (1 - MACHEP) */
# define PI		 3.14159265358979323846		/* pi */
# define PIO2		 1.57079632679489661923		/* pi / 2 */
# define PIO4		 7.85398163397448309616e-1	/* pi / 4 */
# define SQRT2		 1.41421356237309504880		/* sqrt(2) */
# define SQRTH		 7.07106781186547524401e-1	/* sqrt(2) / 2 */
# define LOG2E		 1.4426950408889634073599	/* 1 / log(2) */
# define SQ2OPI		 7.9788456080286535587989e-1	/* sqrt(2 / pi) */
# define LOGE2		 6.93147180559945309417e-1	/* log(2) */
# define LOGSQ2		 3.46573590279972654709e-1	/* log(2) / 2 */
# define THPIO4		 2.35619449019234492885		/* 3 * pi / 4 */
# define TWOOPI		 6.36619772367581343075535e-1	/* 2 / pi */

# define SQRT05		 0.70710678118654752440		/* sqrt(0.5) */
# define ONEOPI		 0.318309886183790672		/* 1 / pi */
# define ONEOPIO2	 0.636619772367581343		/* 1 / (pi / 2) */

# define ROOTEPS	 0.372529029846191406e-8	/* 2 ** -(56/2) */
