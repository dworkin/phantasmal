/*
 * NAME:	verbinfo.h
 * DESCRIPTION:	access fields into verb data arrays
 */

/* info attributes (MOO call stack) */

# define I_FLAGS	 0
# define I_PRGMR	 1
# define I_VARS		 2
# define I_VARDEFS	 3
# define I_NAME		 4
# define I_THIS		 5
# define I_PLAYER	 6
# define I_TASKID	 7
# define I_LINENO	 8
# define I_VERBOBJ	 9
# define I_HOSTOBJ	10
# define I_DEPTH	11
# define I_LINK		12

/* info flags */

# define IF_DEBUG	0x01
# define IF_SUSPENDED	0x02
# define IF_WIZARD	0x04
# define IF_FROMLPC	0x08

/* builtin variables */

# define V_PLAYER	 0
# define V_THIS		 1
# define V_CALLER	 2
# define V_ARGS		 3
# define V_ARGSTR	 4
# define V_VERB		 5
# define V_DOBJ		 6
# define V_DOBJSTR	 7
# define V_PREPSTR	 8
# define V_IOBJ		 9
# define V_IOBJSTR	10
# define V_NUM		11
# define V_OBJ		12
# define V_STR		13
# define V_LIST		14
# define V_ERR		15
# define V_FLOAT	16
# define V_TABLE	17
# define V_BUF		18

# define VAR_OFFSET	19
