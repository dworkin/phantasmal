/*
 * NAME:	tokens.h
 * DESCRIPTION:	compiler tokens
 */

/* The 0x80 bit is reserved for the unparser/detokenizer */

# define TOK_EOF	0x00
# define TOK_NOP	0x00	/* used to preserve line numbers */

# define TOK_COMMENT	0x41			/* 'A' */

# define TOK_LIT_NUM	0x42			/* 'B' */
# define TOK_LIT_STR	0x43
# define TOK_LIT_OBJ	0x44
# define TOK_LIT_ERR	0x45
# define TOK_LIT_FLT	0x46			/* 'F' */

# define TOK_IDENTIFIER	0x47			/* 'G' */

# define TOK_U_MINUS	0x48			/* 'H' */

# define TOK_LPAREN	'('
# define TOK_RPAREN	')'
# define TOK_LBRACKET	'['
# define TOK_RBRACKET	']'
# define TOK_DOLLAR	'$'
# define TOK_PERCENT	'%'
# define TOK_QUESTION	'?'
# define TOK_PIPE	'|'
# define TOK_BANG	'!'
# define TOK_MINUS	'-'
# define TOK_PLUS	'+'
# define TOK_LBRACE	'{'
# define TOK_RBRACE	'}'
# define TOK_SPLICE	'@'
# define TOK_ASSOC	'~'
# define TOK_COMMA	','
# define TOK_SEMICOLON	';'
# define TOK_COLON	':'
# define TOK_DOT	'.'	/* larger token: ".." */
# define TOK_ASSIGN	'='	/* larger token: "==" */
# define TOK_TIMES	'*'	/* also comment delimeter */
# define TOK_DIVIDE	'/'	/* also comment delimeter */
# define TOK_LESS	'<'
# define TOK_GREATER	'>'

# define TOK_IF		0x49			/* 'I' */
# define TOK_ELSEIF	0x4a
# define TOK_ELSE	0x4b
# define TOK_ENDIF	0x4c
# define TOK_FOR	0x4d
# define TOK_IN		0x4e
# define TOK_ENDFOR	0x4f
# define TOK_WHILE	0x50
# define TOK_ENDWHILE	0x51
# define TOK_FORK	0x52
# define TOK_ENDFORK	0x53
# define TOK_RETURN	0x54			/* 'T' */

# define TOK_RANGE	0x55	/* .. */	/* 'U' */
# define TOK_EQUAL	0x56	/* == */
# define TOK_NEQUAL	0x57	/* != */
# define TOK_LSEQUAL	0x58	/* <= */
# define TOK_GREQUAL	0x59	/* >= */
# define TOK_AND	0x5a	/* && */	/* 'Z' */
# define TOK_OR		0x61	/* || */	/* 'a' */

# define TOK_LIST	0x62			/* 'b' */
# define TOK_TABLE	0x63
# define TOK_AMBAGGR	0x64
# define TOK_BUFFER	0x65			/* 'e' */

# define VTOK_BUF	0x66			/* 'f' */
# define VTOK_ERR	0x67
# define VTOK_FLOAT	0x68
# define VTOK_LIST	0x69
# define VTOK_NUM	0x6a
# define VTOK_OBJ	0x6b
# define VTOK_STR	0x6c
# define VTOK_TABLE	0x6d
# define VTOK_PLAYER	0x6e
# define VTOK_THIS	0x6f
# define VTOK_CALLER	0x70
# define VTOK_ARGS	0x71
# define VTOK_ARGSTR	0x72
# define VTOK_VERB	0x73
# define VTOK_DOBJ	0x74
# define VTOK_DOBJSTR	0x75
# define VTOK_PREPSTR	0x76
# define VTOK_IOBJ	0x77
# define VTOK_IOBJSTR	0x78			/* 'x' */

# define MOO_KEYWORDS	\
  ([ "if"	: TOK_IF,	\
     "elseif"	: TOK_ELSEIF,	\
     "else"	: TOK_ELSE,	\
     "endif"	: TOK_ENDIF,	\
     "for"	: TOK_FOR,	\
     "in"	: TOK_IN,	\
     "endfor"	: TOK_ENDFOR,	\
     "while"	: TOK_WHILE,	\
     "endwhile"	: TOK_ENDWHILE,	\
     "fork"	: TOK_FORK,	\
     "endfork"	: TOK_ENDFORK,	\
     "return"	: TOK_RETURN,	\
  ])

# define TOK_MASK	0x7f
# define TAG(ast)	((ast)[0] & TOK_MASK)

# define TF_SIMPLE	0x0100
# define SIMPLE(ast)	((ast)[0] & TF_SIMPLE)
