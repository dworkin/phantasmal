inherit "/std/verb";

# define RUNTIME
# include <moo/verb.h>
