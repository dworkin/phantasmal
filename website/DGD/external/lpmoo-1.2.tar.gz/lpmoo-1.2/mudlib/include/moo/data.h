/*
 * NAME:	moo/data.h
 * DESCRIPTION:	macros for manipulating MOO data values
 */

# include <moo/types.h>

# define NUM(x)		(x)				/* int */
# define STR(x)		(x)				/* string */
# define OBJ(x)		(TE_OBJ + (string) (x))		/* string */
# define ERR(x)		(TE_ERR + (string) (x))		/* string */
# define LST(x)		(x)				/* array */
# define STW(x)		(TE_STW + (string) (x))		/* string */
# define FLT(x)		(x)				/* float */
# define TBL(x)		(x)				/* mapping */
# define BUF(x)		(TE_BUF + (x))			/* string */
# define IST(x)		(TE_IST + (x))			/* string */

# define NUMVAL(x)	(x)
# define STRVAL(x)	(x)
# define OBJVAL(x)	((int) (x)[1 ..])
# define ERRVAL(x)	((int) (x)[1 ..])
# define LSTVAL(x)	(x)
# define STWVAL(x)	((int) (x)[1 ..])
# define FLTVAL(x)	(x)
# define TBLVAL(x)	(x)
# define BUFVAL(x)	((x)[1 ..])
# define ISTVAL(x)	((x)[1 ..])

# define NUMP(x)	intp(x)
# define STRP(x)	(stringp(x) && (! strlen(x) || ! ((x)[0] & TE_MAGIC)))
# define OBJP(x)	(stringp(x) && strlen(x) && (x)[0] == TE_OBJ[0])
# define ERRP(x)	(stringp(x) && strlen(x) && (x)[0] == TE_ERR[0])
# define LSTP(x)	arrayp(x)
# define STWP(x)	(stringp(x) && strlen(x) && (x)[0] == TE_STW[0])
# define FLTP(x)	floatp(x)
# define TBLP(x)	mappingp(x)
# define BUFP(x)	(stringp(x) && strlen(x) && (x)[0] == TE_BUF[0])
# define ISTP(x)	(stringp(x) && strlen(x) && (x)[0] == TE_IST[0])

# define TYPEOF(x)		moo_typeof(x)
# define TRUTHOF(x)		moo_truthof(x)
# define EQUALP(x, y)		moo_equalp(x, y)

# define LNEW()			({ })
# define LAPPEND(x, y)		((x) += ({ y }) )

# define TNEW()			([ ])
# define TLOOKUP(x, y)		moo_tlookup(x, y)
# define TINSERT(x, y, z)	moo_tinsert(x, y, z)
# define TDELETE(x, y)		moo_tdelete(x, y)
# define TMERGE(x, y)		moo_tmerge(x, y)
# define TCOMPARE(x, y)		moo_tcompare(x, y)
# define TKEYS(x)		moo_tkeys(x)
# define TVALUES(x)		moo_tvalues(x)

# define OBJLIST2MOO(x)		objlist2moo(x)
# define STRLIST2MOO(x)		(x)

# define MOOOBJ_NAME(x)		("/moo/" + (string) (x))
# define MOOOBJ(x)		find_object(MOOOBJ_NAME(x))
# define MOOOBJ_NAMEP(x)	sscanf((x), "/moo/%*d")
# define MOOOBJP(x)		MOOOBJ_NAMEP(object_name(x))

# define OBJNUM(x)		((int) object_name(x)[5 ..])
# define OBJ_OBJNUM(x)		(TE_OBJ + object_name(x)[5 ..])
