/*
 * NAME:	config.h
 * DESCRIPTION:	MOO configuration items
 */

# define CF_MOO_VERSION		 0
# define CF_LPMOO_VERSION	 1

# define CF_TELNET_PORT		 2
# define CF_BINARY_PORT		 3

# define CF_EVAL_BACKDOOR	 4

# define CF_OOB_PREFIX		 5
# define CF_LOG_COMMANDS	 6

# define CF_FG_TICKS		 7
# define CF_BG_TICKS		 8
# define CF_FG_SECONDS		 9
# define CF_BG_SECONDS		10

# define CF_OUTBOUND_NET	11
# define CF_MPORT_LISTENING	12
# define CF_SERVER_MSGS		13

# define CF_CONNECT_TIMEOUT	14

# define CF_PATTERN_CACHE	15
# define CF_VERB_CACHE		16

# define CF_MAX_VERB_DEPTH	17
# define CF_STACK_SIZE		18
# define CF_SWAP_INTERVAL	19
# define CF_MEMORY_THRESH	20

# define CF_TIMEZONE		21

# define CF_BOOTSTRAP_FILE	22
# define CF_CHECKPOINT_FILE	23
# define CF_LOG_FILE		24

# define CF_HUH_FAILED_MSG	25
# define CF_PREPOSITIONS	26
# define CF_PROTECTED_BFUNS	27

# define CF_MAX_EXEC		28
