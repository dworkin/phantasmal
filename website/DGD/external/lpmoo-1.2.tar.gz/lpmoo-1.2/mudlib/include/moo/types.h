/*
 * NAME:	moo/types.h
 * DESCRIPTION:	moo datatypes
 */

# define MOOVAL		mixed

# define T_NUM		0	/* NUM */
# define T_OBJ		1	/* OBJ */
# define T_STR		2	/* STR */
# define T_ERR		3	/* ERR */
# define T_LST		4	/* LIST */
# define T_STW		5	/* internal type or "clear" value */
# define T_FLT		6	/* FLOAT */
# define T_TBL		7	/* TABLE */
# define T_BUF		8	/* BUF */
# define T_IST		9	/* internal storage class */

# define TE_MAGIC	0x80
# define TE_OBJ		"\201"	/* (T_OBJ | TE_MAGIC) */
# define TE_STR		"\202"	/* (T_STR | TE_MAGIC) */
# define TE_ERR		"\203"	/* (T_ERR | TE_MAGIC) */
# define TE_STW		"\205"	/* (T_STW | TE_MAGIC) */
# define TE_BUF		"\210"	/* (T_BUF | TE_MAGIC) */
# define TE_IST		"\211"	/* (T_IST | TE_MAGIC) */
