/*
 * NAME:	perms.h
 * DESCRIPTION:	permission bits for various things
 */

# define P_READ		0x01
# define P_WRITE	0x02

# define P_FERTILE	0x04
# define P_CHOWN	0x04
# define P_EXECUTE	0x04

# define P_DEBUG	0x08
