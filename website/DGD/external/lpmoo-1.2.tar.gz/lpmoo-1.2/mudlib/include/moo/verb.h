/*
 * NAME:	verb.h
 * DESCRIPTION:	runtime macros for compiled verb objects
 */

# include <objects.h>
# include <moo/verbinfo.h>
# include <moo/data.h>
# include <moo/errors.h>

# ifdef RUNTIME
# define VARS			vars
# define SP			sp
# define RESET()		(GET_SP(), GET_VARS())
# define STORE()		PUT_SP()
# else  /* ! RUNTIME */
# define VARS			info[I_VARS]
# define SP			stack[0]
# define RESET()		/* do nothing */
# define STORE()		/* do nothing */
# endif

# define RAISE(error)		raise(error, info)

# define PUSH(val)		(stack[++SP] = (val))
# define POP()			(stack[SP--])

# define GET_VARS()		(vars = info[I_VARS])
# define PUT_VARS()		(info[I_VARS] = vars)

# define GET_SP()		(sp = stack[0])
# define PUT_SP()		(stack[0] = sp)

# define LINENO(line)		(lineno = (line))

# define KFUN1(func, arg1)		k_##func(info, arg1)
# define KFUN2(func, arg1, arg2)	k_##func(info, arg1, arg2)
# define KFUN3(func, arg1, arg2, arg3)	k_##func(info, arg1, arg2, arg3)

# define PREP_FORK(id)		prep_fork(stack, info, id)

# ifdef INLINE_PUSHVAR
# define VAR(var)  \
  (info[I_VARDEFS][var - VAR_OFFSET] == '0' ? RAISE(E_VARNF) : VARS[var])
# else
# define VAR(x)			var(info, x)
# endif

# define TYPEOF(x)		moo_typeof(x)
# define TRUTHOF(x)		moo_truthof(x)
# define EQUALP(x, y)		moo_equalp(x, y)

# define PROGRAMMER(info)	(info[I_PRGMR])
# define WIZARDP(info)		(info[I_FLAGS] & IF_WIZARD)

# define JS_BEGIN  \
  mixed RET; if (js && js[1])  \
    { RET = call_other(js[1], js[2], js[3]...); RESET(); }  \
  switch (js ? js[0] : 0) { case 0:
# define JS_PREP(NUM)	STORE(); if (0) { case NUM: js = 0; } else {
# define JS_JUMP(NUM)	case NUM:
# define JS_END		}

# define JS_DATA(n)	stack, info, n, js
# define JS_PROTO	mixed *stack, mixed *info, int bjump, mixed *js

# define JS_INIT_I(cs)	allocate(global->get_stack_size()), cs, 0, 0
# define JS_INIT	JS_INIT_I(0)

# define STD_VARS  \
  NUM(T_NUM) /* NUM   */, NUM(T_OBJ) /* OBJ */, NUM(T_STR) /* STR   */,  \
  NUM(T_LST) /* LIST  */, NUM(T_ERR) /* ERR */, NUM(T_FLT) /* FLOAT */,  \
  NUM(T_TBL) /* TABLE */, NUM(T_BUF) /* BUF */
