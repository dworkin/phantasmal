/*
 * NAME:	command.h
 * DESCRIPTION:	structure of a parsed command record
 */

# define C_ARGS			 0
# define C_ARGSTR		 1
# define C_DOBJ			 2
# define C_PREP			 3
# define C_IOBJ			 4
# define C_DOBJSTR		 5
# define C_PREPSTR		 6
# define C_IOBJSTR		 7

# define MATCH_NOTHING		-1
# define MATCH_AMBIGUOUS	-2
# define MATCH_FAIL		-3

# define VS_NONE		-1
# define VS_ANY			-2
# define VS_THIS		-3
