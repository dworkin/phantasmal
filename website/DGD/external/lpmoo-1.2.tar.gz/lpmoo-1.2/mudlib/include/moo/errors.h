/*
 * NAME:	moo/errors.h
 * DESCRIPTION:	list of MOO errors
 */

# define E_NONE		 0
# define E_TYPE		 1
# define E_DIV		 2
# define E_PERM		 3
# define E_PROPNF	 4
# define E_VERBNF	 5
# define E_VARNF	 6
# define E_INVIND	 7
# define E_RECMOVE	 8
# define E_MAXREC	 9
# define E_RANGE	10
# define E_ARGS		11
# define E_NACC		12
# define E_INVARG	13
# define E_QUOTA	14
# define E_OVERFL	15

# define MOO_ERRORS  \
  ([ "E_NONE"		: E_NONE    + 1,  \
     "E_TYPE"		: E_TYPE    + 1,  \
     "E_DIV"		: E_DIV     + 1,  \
     "E_PERM"		: E_PERM    + 1,  \
     "E_PROPNF"		: E_PROPNF  + 1,  \
     "E_VERBNF"		: E_VERBNF  + 1,  \
     "E_VARNF"		: E_VARNF   + 1,  \
     "E_INVIND"		: E_INVIND  + 1,  \
     "E_RECMOVE"	: E_RECMOVE + 1,  \
     "E_MAXREC"		: E_MAXREC  + 1,  \
     "E_RANGE"		: E_RANGE   + 1,  \
     "E_ARGS"		: E_ARGS    + 1,  \
     "E_NACC"		: E_NACC    + 1,  \
     "E_INVARG"		: E_INVARG  + 1,  \
     "E_QUOTA"		: E_QUOTA   + 1,  \
     "E_OVERFL"		: E_OVERFL  + 1,  \
  ])

# define ERROR_NAMES  \
  ({ "E_NONE",  "E_TYPE",   "E_DIV",     "E_PERM",   "E_PROPNF", "E_VERBNF",  \
     "E_VARNF", "E_INVIND", "E_RECMOVE", "E_MAXREC", "E_RANGE",  "E_ARGS",    \
     "E_NACC",  "E_INVARG", "E_QUOTA",   "E_OVERFL",                          \
  })

# define ERROR_DESCS  \
  ({ "No error",			"Type mismatch",		 \
     "Division by zero",		"Permission denied",		 \
     "Property not found",		"Verb not found",		 \
     "Variable not found",		"Invalid indirection",		 \
     "Recursive move",			"Too many verb calls",		 \
     "Range error",			"Incorrect number of arguments", \
     "Move refused by destination",	"Invalid argument",		 \
     "Object ownership quota exceeded",	"Floating point overflow",	 \
  })
