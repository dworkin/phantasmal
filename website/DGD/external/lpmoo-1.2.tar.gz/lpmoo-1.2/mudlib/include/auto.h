/*
 * NAME:	auto.h
 * DESCRIPTION:	global auto include file
 */

# include <dgd/type.h>

# define intp(var)	(typeof(var) == T_INT)
# define floatp(var)	(typeof(var) == T_FLOAT)
# define stringp(var)	(typeof(var) == T_STRING)
# define objectp(var)	(typeof(var) == T_OBJECT)
# define arrayp(var)	(typeof(var) == T_ARRAY)
# define mappingp(var)	(typeof(var) == T_MAPPING)

# define stderr(msg)	DRIVER->notify(msg)
# define debug(msg)	(DEBUG ? stderr(">> " + (msg)) : 0)
