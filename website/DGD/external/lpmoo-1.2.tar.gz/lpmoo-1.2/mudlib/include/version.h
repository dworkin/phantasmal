/*
 * NAME:	version.h
 * DESCRIPTION:	macros for this version of LPMOO
 */

# define VERSION_MOO	"1.7.8"
# define VERSION_LPMOO	"1.2"
