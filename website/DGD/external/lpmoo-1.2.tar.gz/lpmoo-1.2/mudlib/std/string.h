/*
 * NAME:	string.h
 * DESCRIPTION:	prototypes and constants for string.c
 */

# define SPACES \
  "                                                                           "

static int strchr(string str, int char);
static int strrchr(string str, int char);

static varargs string column_list(string *items, int maxwidth, int pad);

static string toupper(string str);
static string tolower(string str);

static string subst(string str, int index, int len, string newsubst);
static string strip_whitespace(string str);

static string escape_sscanf_str(string str);
static string escape_str(string str);
static string unescape_str(string str);
