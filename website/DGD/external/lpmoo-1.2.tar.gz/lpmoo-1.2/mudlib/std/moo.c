/*
 * NAME:	moo.c
 * DESCRIPTION:	LPC interface to MOO objects
 */

inherit "/std/core";
inherit "/std/data";
inherit "/std/string";

# include <moo/data.h>
# include <moo/errors.h>

/*
 * NAME:	getprop()
 * DESCRIPTION:	return the contents of a property, or raise an error
 */
static
mixed getprop(object obj, string name)
{
  MOOVAL result;

  if (! obj || ! MOOOBJP(obj))
    error("Argument 1 is not a MOO object");

  result = obj->safe_get_property(name);
  if (STWP(result))
    error(global->error_desc(STWVAL(result)));
  else
    return moo2lpc(result);
}

/*
 * NAME:	setprop()
 * DESCRIPTION:	change the contents of a property
 */
static
void setprop(object obj, string name, mixed newvalue)
{
  int result;

  if (! obj || ! MOOOBJP(obj))
    error("Argument 1 is not a MOO object");

  result = obj->safe_set_property(name, lpc2moo(newvalue));
  if (result != E_NONE)
    error(global->error_desc(result));
}

/*
 * NAME:	callverb()
 * DESCRIPTION:	call a MOO verb and return the result
 */
static varargs
mixed callverb(object obj, string verb, mixed args...)
{
  error("callverb() not yet implemented");
}
