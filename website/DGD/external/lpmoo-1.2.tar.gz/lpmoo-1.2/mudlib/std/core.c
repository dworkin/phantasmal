/*
 * NAME:	core.c
 * DESCRIPTION:	base for most objects
 */

# include <objects.h>

object global, parser, compiler, unparser, btable;

/*
 * NAME:	create()
 * DESCRIPTION:	initialize the object
 */
static
void create(void)
{
  global   = load_object(GLOBAL);
  parser   = load_object(PARSER);
  compiler = load_object(COMPILER);
  unparser = load_object(UNPARSER);
  btable   = load_object(BTABLE);
}
