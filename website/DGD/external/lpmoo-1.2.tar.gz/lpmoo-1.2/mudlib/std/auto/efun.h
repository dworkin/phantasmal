/*
 * NAME:	efun.h
 * DESCRIPTION:	prototypes for external functions
 */

static object load_object(string file);
static object compile_object(string lpc_code);

static varargs mixed with_lock(string func, mixed args...);
