/*
 * NAME:	moo.h
 * DESCRIPTION:	prototypes for moo.c
 */

# include <moo/types.h>

static void	save_db(string file);

static MOOVAL	raise(int error, mixed *info);

static int	wizardp(int programmer);
static int	programmerp(int programmer);
