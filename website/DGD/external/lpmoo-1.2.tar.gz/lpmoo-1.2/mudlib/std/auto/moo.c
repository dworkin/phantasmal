/*
 * NAME:	moo.c
 * DESCRIPTION:	functions for facilitating MOO emulation
 */

# include <moo/data.h>
# include <moo/verbinfo.h>

static
void save_db(string file)
{
  object saver;

  lock(saver = load_object(DBSAVER),
       saver->main(file),
       destruct_object(saver));
}

static
MOOVAL raise(int error, mixed *info)
{
  if (info[I_FLAGS] & IF_DEBUG)
    error("E!" + GLOBAL->error_desc(error));
  else
    return ERR(error);
}

static
int wizardp(int programmer)
{
  object ob;

  return (ob = MOOOBJ(programmer)) ? ob->is_wizard() : 0;
}

static
int programmerp(int programmer)
{
  object ob;

  return (ob = MOOOBJ(programmer)) ? ob->is_programmer() : 0;
}

static
void input_to(string func)
{
  object user;

  if (! (user = this_user()))
    error("Invalid input_to() from call_out()");

  if (func && ! function_object(func, this_object()))
    error("Invalid function for input_to()");

  if (! user->input_to(this_object(), func))
    error("Already expecting input");
}
