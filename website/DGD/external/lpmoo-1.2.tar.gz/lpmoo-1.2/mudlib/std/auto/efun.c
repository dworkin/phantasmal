/*
 * NAME:	efun.c
 * DESCRIPTION:	external functions
 */

static
object load_object(string file)
{
  call_other(file, "???");
  return find_object(file);
}

static
object compile_object(string lpc_code)
{
  object master;
  string file;

  file = "/tmp/compiled_" + (string) GLOBAL->unique_number();

  remove_file(file + ".c");
  write_file(file + ".c", lpc_code);

  master = find_object(file);
  if (master != 0)
    destruct_object(master);

  catch(call_other(file, "???"));
  remove_file(file + ".c");

  return find_object(file);
}

static varargs
mixed with_lock(string func, mixed args...)
{ return lock(call_other(this_object(), func, args...)); }
