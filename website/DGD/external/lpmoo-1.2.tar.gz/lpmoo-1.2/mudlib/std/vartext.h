/*
 * NAME:	vartext.h
 * DESCRIPTION:	variable-to-text translator defines
 */

static string type_str(mixed var);
static string var2str(mixed var);
static mixed str2var(string str);
