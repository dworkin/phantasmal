/*
 * NAME:	bfuns.c
 * DESCRIPTION:	builtin MOO functions
 */

# define DEBUG  0

inherit "/std/core";
inherit "/std/data";
inherit "/std/math";

# include <objects.h>
# include <moo/verb.h>
# include <moo/perms.h>
# include <moo/config.h>
# include <dgd/status.h>
# include <dgd/limits.h>

# define ASSERT(arg, type)	if (! type##P(arg)) return RAISE(E_TYPE)

# define GET_VALID_OBJ(x, y)  \
  if (! (x = MOOOBJ(y))) return RAISE(E_INVARG)

# include "bfuns/moofuns.c"
# include "bfuns/dgdfuns.c"
# include "bfuns/extrafuns.c"
