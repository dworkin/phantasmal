/*
 * NAME:	auto.c
 * DESCRIPTION:	so-called auto object, automatically inherited everywhere
 */

# include <objects.h>

# include "auto/efun.h"
# include "auto/moo.h"

# include "auto/efun.c"
# include "auto/moo.c"
