/*
 * NAME:	dgdfuns.c
 * DESCRIPTION:	builtin dgd_* functions
 */

# ifdef FUNCDEF
FUNCDEF(0, "dgd_server_version", 0, 0)
# else

/*
 * NAME:	bfun->dgd_server_version()
 * DESCRIPTION:	return the current running version of DGD
 */
varargs
MOOVAL b_dgd_server_version(mixed *info)
{
  return STR(status()[ST_VERSION]);
}
# endif

# ifdef FUNCDEF
FUNCDEF(0, "dgd_lpmoo_version", 0, 0)
# else

/*
 * NAME:	bfun->dgd_lpmoo_version()
 * DESCRIPTION:	return the current running version of LPMOO
 */
varargs
MOOVAL b_dgd_lpmoo_version(mixed *info)
{
  return STR(CONFIG->query(CF_LPMOO_VERSION));
}
# endif

# ifdef FUNCDEF
FUNCDEF(0, "dgd_status", 0, 2)
# else

/*
 * NAME:	bfun->dgd_status()
 * DESCRIPTION:	return statistics about the state of DGD
 */
varargs
MOOVAL b_dgd_status(mixed *info, MOOVAL args...)
{
  object ob;
  mixed *status;

  if (sizeof(args))
    {
      ASSERT(args[0], OBJ);
      GET_VALID_OBJ(ob, OBJVAL(args[0]));

      if (sizeof(args) > 1)
	{
	  ASSERT(args[1], STR);
	  if (! (ob = ob->get_verb_obj(STRVAL(args[1]))))
	    return RAISE(E_INVARG);
	}
    }

  if (ob)
    {
      status = status(ob);
      return LST( ({
	NUM(status[O_COMPILETIME]),
	NUM(status[O_PROGSIZE]),
	NUM(status[O_DATASIZE]),
	NUM(status[O_NSECTORS]),
      }) );
    }
  else
    {
      status = status();
      return LST( ({
	NUM(status[ST_STARTTIME]),
	NUM(status[ST_BOOTTIME]),
	NUM(status[ST_UPTIME]),

	NUM(status[ST_SWAPSIZE]),
	NUM(status[ST_SWAPUSED]),
	NUM(status[ST_SECTORSIZE]),
	NUM(status[ST_SWAPRATE1]),
	NUM(status[ST_SWAPRATE5]),

	NUM(status[ST_SMEMSIZE]),
	NUM(status[ST_SMEMUSED]),
	NUM(status[ST_DMEMSIZE]),
	NUM(status[ST_DMEMUSED]),

	NUM(status[ST_OTABSIZE]),
	NUM(status[ST_NOBJECTS]),
	NUM(status[ST_COTABSIZE]),
	NUM(status[ST_NCOSHORT] + status[ST_NCOLONG]),
	NUM(status[ST_UTABSIZE]),
	NUM(sizeof(users())),

	NUM(DRIVER->query_net() != 0),
	NUM(CONFIG->query(CF_OUTBOUND_NET) != 0),
	NUM(CONFIG->query(CF_MPORT_LISTENING) != 0),
	NUM(CONFIG->query(CF_SERVER_MSGS) != 0),

	NUM(CONFIG->query(CF_TELNET_PORT)),
	NUM(CONFIG->query(CF_BINARY_PORT)),

	LST(DRIVER->query_ports()),
      }) );
    }
}
# endif

# ifdef FUNCDEF
FUNCDEF(0, "dgd_object_name", 1, 2)
# else

/*
 * NAME:	bfun->dgd_object_name()
 * DESCRIPTION:	return the DGD object name for a MOO object or verb
 */
varargs
MOOVAL b_dgd_object_name(mixed *info, MOOVAL arg1, MOOVAL etc...)
{
  object ob;

  ASSERT(arg1, OBJ);
  GET_VALID_OBJ(ob, OBJVAL(arg1));

  if (sizeof(etc))
    {
      ASSERT(etc[0], STR);
      if (! (ob = ob->get_verb_obj(STRVAL(etc[0]))))
	return RAISE(E_INVARG);
    }

  return STR(object_name(ob));
}
# endif

# ifdef FUNCDEF
FUNCDEF(0, "dgd_checkpoint_db", 0, 0)
# else

/*
 * NAME:	bfun->dgd_checkpoint_db()
 * DESCRIPTION:	write a text dump (obsolete)
 */
varargs
MOOVAL b_dgd_checkpoint_db(mixed *info)
{
  if (! WIZARDP(info))
    return RAISE(E_PERM);

  DRIVER->log("Warning: call to deprecated dgd_checkpoint_db()");
  global->dump_database(1);

  return NUM(0);
}
# endif

# ifdef FUNCDEF
FUNCDEF(0, "dgd_swapout", 0, 0)
# else

/*
 * NAME:	bfun->dgd_swapout()
 * DESCRIPTION:	swap out all DGD objects
 */
varargs
MOOVAL b_dgd_swapout(mixed *info)
{
  if (! WIZARDP(info))
    return RAISE(E_PERM);

  swapout();

  return NUM(0);
}
# endif

# ifdef FUNCDEF
FUNCDEF(0, "dgd_set_prompt", 2, 2)
# else

/*
 * NAME:	bfun->dgd_set_prompt()
 * DESCRIPTION:	change a connection's input prompt
 */
varargs
MOOVAL b_dgd_set_prompt(mixed *info, MOOVAL arg1, MOOVAL arg2)
{
  object ob;
  int id;

  ASSERT(arg1, OBJ);
  ASSERT(arg2, STR);

  id = OBJVAL(arg1);

  if (PROGRAMMER(info) != id &&
      ! WIZARDP(info))
    return RAISE(E_PERM);

  if (ob = MOOOBJ(id))
    ob = global->get_connection_obj(ob);
  else
    ob = global->get_unlogged_in(id);

  if (! ob)
    return RAISE(E_INVARG);

  ob->set_prompt(STRVAL(arg2));

  return NUM(0);
}
# endif

# ifdef FUNCDEF
FUNCDEF(0, "dgd_get_prompt", 1, 1)
# else

/*
 * NAME:	bfun->dgd_get_prompt()
 * DESCRIPTION:	return the connection's current input prompt
 */
varargs
MOOVAL b_dgd_get_prompt(mixed *info, MOOVAL arg)
{
  object ob;
  int id;

  ASSERT(arg, OBJ);
  id = OBJVAL(arg);

  if (PROGRAMMER(info) != id &&
      ! WIZARDP(info))
    return RAISE(E_PERM);

  if (ob = MOOOBJ(id))
    ob = global->get_connection_obj(ob);
  else
    ob = global->get_unlogged_in(id);

  return ob ? STR(ob->get_prompt()) : RAISE(E_INVARG);
}
# endif

# ifdef FUNCDEF
FUNCDEF(0, "dgd_set_noecho", 1, 1)
# else

/*
 * NAME:	bfun->dgd_set_noecho()
 * DESCRIPTION:	make a connection not echo the next line of input
 */
varargs
MOOVAL b_dgd_set_noecho(mixed *info, MOOVAL arg)
{
  object ob;
  int ret, id;

  ASSERT(arg, OBJ);
  id = OBJVAL(arg);

  if (PROGRAMMER(info) != id &&
      ! WIZARDP(info))
    return RAISE(E_PERM);

  if (ob = MOOOBJ(id))
    ob = global->get_connection_obj(ob);
  else
    ob = global->get_unlogged_in(id);

  if (! ob)
    return RAISE(E_INVARG);

  ret = ob->set_noecho();

  return (ret == E_NONE) ? NUM(0) : RAISE(ret);
}
# endif

# ifdef FUNCDEF
FUNCDEF(0, "dgd_ip_number", 1, 1)
# else

/*
 * NAME:	bfun->dgd_ip_number()
 * DESCRIPTION:	return a connection's remote IP address
 */
varargs
MOOVAL b_dgd_ip_number(mixed *info, MOOVAL arg)
{
  object ob;
  int id;

  ASSERT(arg, OBJ);
  id = OBJVAL(arg);

  if (PROGRAMMER(info) != id &&
      ! WIZARDP(info))
    return RAISE(E_PERM);

  if (ob = MOOOBJ(id))
    ob = global->get_connection_obj(ob);
  else
    ob = global->get_unlogged_in(id);

  return ob ? STR(query_ip_number(ob)) : RAISE(E_INVARG);
}
# endif

# ifdef FUNCDEF
FUNCDEF(0, "dgd_port_number", 1, 1)
# else

/*
 * NAME:	bfun->dgd_port_number()
 * DESCRIPTION:	return a connection's remote port number
 */
varargs
MOOVAL b_dgd_port_number(mixed *info, MOOVAL arg)
{
  object ob;
  int id, port;

  ASSERT(arg, OBJ);
  id = OBJVAL(arg);

  if (PROGRAMMER(info) != id &&
      ! WIZARDP(info))
    return RAISE(E_PERM);

  if (ob = MOOOBJ(id))
    ob = global->get_connection_obj(ob);
  else
    ob = global->get_unlogged_in(id);

  if (! ob)
    return RAISE(E_INVARG);

  port = ob->get_port_number();

  return port ? NUM(port) : RAISE(E_PERM);
}
# endif
