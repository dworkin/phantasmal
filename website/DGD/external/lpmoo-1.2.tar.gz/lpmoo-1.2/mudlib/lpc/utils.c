/*
 * NAME:	utils.c
 * DESCRIPTION:	minimal LPC primitives useful to call from MOO
 */

/*
 * NAME:	update()
 * DESCRIPTION:	destroy an object so it can be reloaded
 */
int update(string name)
{
  object obj;

  obj = find_object(name);
  if (obj != 0)
    {
      destruct_object(obj);
      return 1;
    }
  else
    return 0;
}

/*
 * NAME:	eval()
 * DESCRIPTION:	evaluate arbitrary LPC code and return the result (if any)
 */
mixed eval(string code)
{
  object obj;
  mixed result;
  string err;

  obj = compile_object("# include <objects.h>\n" +
		       "mixed main(void) { " + code + "; }\n");
  if (obj == 0)
    error("LPC syntax error");

  err = catch(result = obj->main());
  destruct_object(obj);

  if (err)
    error(err);

  return result;
}

/*
 * NAME:	cost_left()
 * DESCRIPTION:	return the remaining DGD execution cost
 */
int cost_left(void)
{
  return get_exec_cost();
}
