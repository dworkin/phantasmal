/*
 * NAME:	rfc822.c
 * DESCRIPTION:	process RFC822-style headers
 */

inherit "/std/string";

private
mapping	headers;	/* field/value pairs of RFC822 headers */

private
string	current_line;	/* current logical header (being built) */

/*
 * NAME:	create()
 * DESCRIPTION:	initialize at creation
 */
static
void create(void)
{
  headers      = ([ ]);
  current_line = "";
}

/*
 * NAME:	complete()
 * DESCRIPTION:	process a complete header
 */
private
void complete(void)
{
  string field, value;
  mixed stored;

  if (sscanf(current_line, "%s:%s", field, value) != 2)
    error("Invalid RFC822 header");

  field = tolower(field);
  value = strip_whitespace(value);

  if (stored = headers[field])
    {
      if (arrayp(stored))
	headers[field] = stored + ({ value });
      else
	headers[field] = ({ stored, value });
    }
  else
    headers[field] = value;

  current_line = "";
}

/*
 * NAME:	receive_line()
 * DESCRIPTION:	build headers from a line of input
 */
static
int receive_line(string line)
{
  if (! strlen(line))
    {
      if (strlen(current_line))
	complete();

      return 0;  /* end of headers */
    }

  if (line[0] == ' ' || line[0] == '\t')
    {
      current_line += line;
      return 1;
    }

  if (strlen(current_line))
    complete();  /* process complete header */

  current_line = line;

  return 1;
}

/*
 * NAME:	get_header()
 * DESCRIPTION:	return the raw value of a header
 */
static
string get_header(string field)
{ return headers[field]; }

/*
 * NAME:	get_headers()
 * DESCRIPTION:	return all headers
 */
static
mapping get_headers(void)
{ return headers; }
