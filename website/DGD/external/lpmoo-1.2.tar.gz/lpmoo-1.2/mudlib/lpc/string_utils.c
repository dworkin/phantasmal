inherit "/std/math";

/*
 * NAME:	$string_utils:space()
 * DESCRIPTION:	return a string consisting of copies of a string
 */
varargs
string space(mixed len, string fill)
{
  int n, m, f;

  if (stringp(len))
    n = strlen(len);
  else
    n = len;

  if (n > 100000)
    error("Argument too large");

  if (! fill)
    fill = " ";
  else if (fill != " ")
    {
      fill = fill + fill;
      fill = fill + fill;
      fill = fill + fill;
    }
  else if ((n = abs(n)) < 70)
    return ("                                   " +
            "                                   ")[.. n - 1];
  else
    fill = "                                   " +
           "                                   ";

  m = (n - 1) / strlen(fill);

  while (m)
    {
      fill = fill + fill;
      m = m / 2;
    }

  return n > 0 ? fill[.. n - 1] : fill[(f = strlen(fill)) + n .. f];
}

/*
 * NAME:	$string_utils:left
 * DESCRIPTION:	left-align a string
 */
varargs
string left(string text, int len, string fill)
{
  int abslen;
  string out;

  if (! fill)
    fill = " ";

  abslen = abs(len);
  out    = text;

  if (strlen(out) < abslen)
    return out + space(strlen(out) - abslen, fill);
  else
    return len > 0 ? out : out[.. abslen - 1];
}

/*
 * NAME:	$string_utils:right
 * DESCRIPTION:	right-align a string
 */
varargs
string right(string text, int len, string fill)
{
  int abslen;
  string out;

  if (! fill)
    fill = " ";

  abslen = abs(len);
  out    = text;

  if (strlen(out) < abslen)
    return space(abslen - strlen(out), fill) + out;
  else
    return len > 0 ? out : out[.. abslen - 1];
}
