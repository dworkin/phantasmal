/*
 * NAME:	http.c
 * DESCRIPTION:	experimental web server
 */

# include <objects.h>
# include "http.h"

mapping status_codes;		/* HTTP status codes */

/*
 * NAME:	create()
 * DESCRIPTION:	initialize data
 */
static
void create(void)
{
  status_codes = ([
		   R_OK			: "OK",
		   R_CREATED		: "Created",
		   R_ACCEPTED		: "Accepted",
		   R_PARTIAL		: "Partial Information",
		   R_NORESPONSE		: "No Response",

		   R_MOVED		: "Moved",
		   R_FOUND		: "Found",
		   R_METHOD		: "Method",
		   R_NOTMODIFIED	: "Not Modified",

		   R_BADREQUEST		: "Bad Request",
		   R_UNAUTHORIZED	: "Unauthorized",
		   R_PAYMENTREQ		: "Payment Required",
		   R_FORBIDDEN		: "Forbidden",
		   R_NOTFOUND		: "Not Found",

		   R_INTERNALERR	: "Internal Error",
		   R_NOTIMPLEM		: "Not Implemented",
		   R_TEMPOVERL		: "Service Temporarily Overloaded",
		   R_GATEWTIMEOUT	: "Gateway Timeout",
		 ]);
}

/*
 * NAME:	process_request()
 * DESCRIPTION:	an HTTP request has been made
 */
varargs
void process_request(string verb, string args...)
{
  if (sizeof(args) < 1 || sizeof(args) > 2)
    error("Invalid HTTP request");

  clone_object(HTTP_REQUEST)->init(verb, args[0],
				   sizeof(args) > 1 ? args[1] : HTTP_09);
}

/*
 * NAME:	status_descrip()
 * DESCRIPTION:	return the description string for a status code
 */
string status_descrip(int status)
{ return status_codes[status]; }

/*
 * NAME:	error_doc()
 * DESCRIPTION:	return an error document
 */
object error_doc(int code, string descrip)
{
  object doc;

  doc = clone_object(ERR_OBJ);
  doc->init(code, descrip);

  return doc;
}
