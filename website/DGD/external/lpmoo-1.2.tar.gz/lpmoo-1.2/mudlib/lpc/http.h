/*
 * NAME:	http.h
 * DESCRIPTION:	macros for HTTP
 */

# define HTTP		"/lpc/http"
# define HTTP_REQUEST	"/lpc/http_request"

# define HTTP_09	"HTTP/0.9"
# define HTTP_SERVER	"DGD-LPMOO/0.1"
# define HTTP_SVERS	"HTTP/1.0"
# define HTTP_MIMEVERS	"1.0"
# define HTTP_WEBMASTER	"rob@ccs.neu.edu"

# define WWW_ROOT	"/www/root"
# define WWW_OBJ(name)	("/www/obj/" + name)
# define ERR_OBJ	WWW_OBJ("error")

# define R_OK		200
# define R_CREATED	201
# define R_ACCEPTED	202
# define R_PARTIAL	203
# define R_NORESPONSE	204

# define R_MOVED	301
# define R_FOUND	302
# define R_METHOD	303
# define R_NOTMODIFIED	304

# define R_BADREQUEST	400
# define R_UNAUTHORIZED	401
# define R_PAYMENTREQ	402
# define R_FORBIDDEN	403
# define R_NOTFOUND	404

# define R_INTERNALERR	500
# define R_NOTIMPLEM	501
# define R_TEMPOVERL	502
# define R_GATEWTIMEOUT	503
