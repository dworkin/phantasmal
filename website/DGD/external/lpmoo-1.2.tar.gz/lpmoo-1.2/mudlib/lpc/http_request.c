/*
 * NAME:	http_request.c
 * DESCRIPTION:	handle an HTTP request
 */

inherit rfc822 "/lpc/rfc822";

# include "http.h"

string	method;			/* the requested method */
string	uri;			/* the requested uniform resource id */
string	pvers;			/* the client protocol version */
string	query;			/* posting/searching information */

object	client;			/* the client object */

/*
 * NAME:	process()
 * DESCRIPTION:	initial request is completed
 */
private
void process(void)
{
  object doc;

  catch(doc = call_other(WWW_ROOT, method, uri, query,
		         rfc822::get_header("accept")));

  if (! doc)
    doc = HTTP->error_doc(R_INTERNALERR,
			  "An internal error prevented the document from " +
			  "being returned.");

  if (pvers != HTTP_09)
    {
      int status;
      string descrip, type;

      status  = doc->status();
      descrip = HTTP->status_descrip(status);
      type    = doc->content_type();

      client->notify(HTTP_SVERS + " " + (string) status + " " + descrip);
      client->notify("MIME-Version: " + HTTP_MIMEVERS);
      client->notify("Server: " + HTTP_SERVER);
      client->notify("Date: " + ctime(time()));
      client->notify("Content-Type: " + type);
      doc->headers(client);
      client->notify("");
    }

  doc->output(client);

  destruct_object(doc);
  call_out("finish", 1);
}

/*
 * NAME:	finish()
 * DESCRIPTION:	close connection and destroy this request object
 */
static
void finish(void)
{
  client->boot();
  destruct_object(this_object());
}

/*
 * NAME:	htrq_body()
 * DESCRIPTION:	receive an HTRQ body line
 */
int htrq_body(string line)
{
  query = line;
  process();

  return 1;
}

/*
 * NAME:	htrq_header()
 * DESCRIPTION:	receive an HTRQ header
 */
int htrq_header(string line)
{
  while (1)
    {
      if (! rfc822::receive_line(line))
	break;

      if (! (line = client->get_line()))
	{
	  input_to("htrq_header");
	  return 1;
	}
    }

  /* headers finished */

  if (method == "POST")
    {
      if (line = client->get_line())
	htrq_body(line);
      else
	input_to("htrq_body");

      return 1;
    }
  else
    process();

  return 1;
}

/*
 * NAME:	init()
 * DESCRIPTION:	called after creation to initialize
 */
void init(string imethod, string iuri, string ipvers)
{
  string line;

  method = imethod;
  uri    = iuri;
  pvers  = ipvers;

  client = this_user();

  if (pvers != HTTP_09)
    {
      if (line = client->get_line())
	htrq_header(line);
      else
	input_to("htrq_header");

      return;
    }

  /* simple request; process immediately */

  process();
}
