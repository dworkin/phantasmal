#!/bin/sh

cd dgd-net/src
for file in *.DGD.? */*.DGD.? */*/*.DGD.?
do
  base=`echo $file | sed -e 's/\.DGD//'`
  diff -c $file $base | (cd ../../dgd/src && patch -p0 -l -s)
done
