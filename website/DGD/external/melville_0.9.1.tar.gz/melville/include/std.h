/* This file has to exist or the driver isn't happy. I believe it's
   included automatically in the auto object. Anyway, I don't have
   anything to put here... so... */

#define PI 3.1415926
