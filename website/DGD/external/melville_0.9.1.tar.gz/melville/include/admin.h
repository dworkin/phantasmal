/* Defines the names of the admin's characters. */

#define ADMIN ({ "mobydick" })
