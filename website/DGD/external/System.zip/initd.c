/*
 * NAME:	initd.c
 * DATE:	13/1/2, Shevek
 * DESCRIPTION:	Setup BB lib at driver startup
 * HISTORY:
 */

# include <bb_config.h>
# include <kernel/access.h>
# include <kernel/user.h>
# include <kernel/rsrc.h>

inherit access API_ACCESS;
inherit rsrc API_RSRC;

/*
 * NAME:	create()
 * DATE:	13/1/2, Shevek
 * DESCRIPTION:	Initialize object
 */
void create() {
	object telnetd,binaryd;
	access::create();
	rsrc::create();

	/* Set up pseudo users */
	add_user("System");     /* Not really needed */
	add_owner("System");    /* Kernel defines it */

	/* System requires root access */
    /* The kernel defines this as well, this is here for example */
	set_access("System", "/", FULL_ACCESS);

	/* These master objects are needed at immediately */
	compile_object(BB_USER);
    compile_object(BB_WIZTOOL);

	/* Set the telnet manager and binary manager to the correct objects */
	telnetd = compile_object("/usr/System/telnetd");
	find_object(USERD)->set_telnet_manager(telnetd);

	binaryd = compile_object("/usr/System/binaryd");
	find_object(USERD)->set_binary_manager(binaryd);
}
