/*
 * NAME:	wiztool.c
 * DATE:	7/2/2, Shevek.
 * DESCRIPTION:	BB wizard functions
 */

# include <kernel/objreg.h>
# include <kernel/rsrc.h>

inherit objreg API_OBJREG;
inherit rsrc API_RSRC;

private string owner;

/* This function is from the wiztool */
static void message(string str);

/*
 * NAME:	create()
 * DATE:	13/1/2, Shevek
 * DESCRIPTION:	initialize object
 */
static void create(){
	objreg::create();
	rsrc::create();
	owner=query_owner();
	return;
}

/*
 * NAME:	cmd_objects()
 * DATE:	13/1/2, Shevek.
 * DESCRIPTION:	Returns all objects owned by named user
 */
static void cmd_objects(object user, string cmd, string str){
	object obj,firstobj;
	if(!str){
		message("Usage: " + cmd + " <owner>\n");
		return;
	}
	if (sizeof(rsrc::query_owners() & ({ str })) != 0) {
		firstobj=obj=first_link(str);
		if(obj){
			message(object_name(obj) + "\n");
			obj=next_link(obj);
			while(obj!=firstobj){
				message(object_name(obj) + "\n");
				obj=next_link(obj);
			}
		}
		else{
			message("No objects registered to that resource owner.\n");
		}
	}
	else{
		message("No such resource owner.\n");
	}
return;
}

