/*
 * NAME:	binaryd.c
 * DATE:	13/1/2, Shevek
 * DESCRIPTION: Provide essential information for binary connections
 */

# include <bb_config.h>
# include <kernel/version.h>


/*
 * NAME:	select()
 * DATE:	13/1/2, Shevek
 * DESCRIPTION:	Select a user object for binary connections
 */
object select(string str) {
	return(clone_object(BB_USER));
}

/*
 * NAME:	query_timeout()
 * DATE:	13/1/2, Shevek
 * DESCRIPTION:	Select the timeout for binary connections
 */
int query_timeout(object connection) {
	return(60);
}

/*
 * NAME:	query_banner()
 * DATE:	13/1/2, Shevek
 * DESCRIPTION:	Select a login banner for binary connections
 */
string query_banner(object connection) {
	string str;
	mixed driverv;
	driverv=status();
	str="DGD driver version " + driverv[0];
	str+="\nKernel lib version " + KERNEL_LIB_VERSION;
	str+="\nBB lib version " + BB_LIB_VERSION;
    str+="\n(Binary) connection.";
	str+="\n\n" + read_file(LOGIN_BANNER);
	return(str);
}
