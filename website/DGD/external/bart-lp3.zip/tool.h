private void badarg(string func, int arg);

static string capitalize(string str);
static string lower_case(string str);
static string set_bit(string str, int bit);
static string clear_bit(string str, int bit);
static int test_bit(string str, int bit);
static varargs string extract(string str, int first, int last);

# define INIT_TOOL()
# define ARGCHECK(t, f, a)	if (!(t)) badarg(#f, a)
