nomask static int member_array(mixed elt, mixed *arr);
nomask static varargs mixed *
filter_array(mixed *arr, string func, mixed obj, mixed arg);
nomask static varargs mixed *map_array(mixed *arr, string func, mixed obj, mixed arg);
nomask static mixed *slice_array(mixed *arr, int first, int last);
nomask static varargs mixed *sort_array(mixed *arr, string func, mixed obj);
nomask static varargs mixed *unique_array(mixed *arr, string func, mixed exclude);
nomask static mixed *a_delete(mixed *arr, int from, varargs int to);
