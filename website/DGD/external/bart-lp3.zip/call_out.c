private mixed heartbeat;	/* hearbeat mode */

/*
 * NAME:	call_out()
 * DESCRIPTION:	handle a call_out
 */
static varargs void call_out(string func, int delay, mixed args...)
{
    ARGCHECK(func, call_out, 1);

    if (function_object(func, this_object()) != AUTO || PRIVILEGED()) {
	rlimits (-1; -1) {
	    add_call_out();
	    ::call_out("_F_call_out", delay, func, this_player(), args...);
	}
    }
}

/*
 * NAME:	_F_call_out()
 * DESCRIPTION:	handle a call_out
 */
nomask varargs void
_F_call_out(string func, object player, mixed args...)
{
    if (previous_program() == 0) {
	del_call_out();
	/* set_this_player(player); */
        set_this_player(0);
        GLOBAL->set_this_interactive(0);
	rlimits (MAXDEPTH; MAXTICKS) {
	    call_other(this_object(), func, args...);
	}
    }
}

/*
 * NAME:	find_call_out()
 * DESCRIPTION:	find a call_out
 */
static int find_call_out(string func)
{
    mixed **clist, *c;
    int i, sz;

    clist = ::status(this_object())[O_CALLOUTS];
    for (i = 0, sz = sizeof(clist); i < sz; i++) {
	if (sizeof(c=clist[i]) > 3 && c[3] == func) {
	    return c[2];
	}
    }
    return -1;
}

/*
 * NAME:	remove_call_out()
 * DESCRIPTION:	remove a call_out
 */
static int remove_call_out(string func)
{
    mixed **clist, *c;
    int i, sz;

    clist = ::status(this_object())[O_CALLOUTS];
    for (i = 0, sz = sizeof(clist); i < sz; i++) {
	if (sizeof(c=clist[i]) > 3 && c[3] == func) {
	    rlimits (-1; -1) {
		del_call_out();
		return ::remove_call_out(c[0]);
	    }
	}
    }
    return -1;
}

/*
 * NAME:	set_heart_beat()
 * DESCRIPTION:	start or stop the heart_beat
 */
static int set_heart_beat(int flag)
{
    if (flag) {
	if (heartbeat == 0) {
	    rlimits (-1; -1) {
	    	add_heart_beat();
		heartbeat = ::call_out("_F_heart_beat", 1 + (time() & 1));
	    }
	    return 1;
	}
    } else {
	if (heartbeat > 0) {
	    rlimits (-1; -1) {
	    	del_heart_beat();
		::remove_call_out(heartbeat);
		heartbeat = 0;
	    }
	    return 1;
	}
	heartbeat = 0;
    }
    return 0;
}

/*
 * NAME:	_F_heart_beat()
 * DESCRIPTION:	handle heart_beat calls
 */
nomask void _F_heart_beat()
{
    if (previous_program() == 0) {
	heartbeat = -1;
	del_heart_beat();
	if (living(this_object())) {
	    set_this_player(this_object());
            GLOBAL->set_this_interactive(0);
	} else {
	    set_this_player(0);
            GLOBAL->set_this_interactive(0);
	}
	rlimits (MAXDEPTH; MAXTICKS) {
	    this_object()->heart_beat();
	}
	if (heartbeat < 0) {
	    add_heart_beat();
	    heartbeat = ::call_out("_F_heart_beat", 1 + (time() & 1));
	}
    }
}
