private string euid;
private string uid;

nomask static void seteuid(string str) {
    if(MASTER->valid_seteuid(str))
        GLOBAL->seteuid(this_object(),str);
}

nomask static varargs string geteuid(object o) {
    if(!o) o = this_object();
    return GLOBAL->_G_geteuid(o);
}

nomask public varargs string getuid(object ob) {
    if(!ob) ob = this_object();
    return GLOBAL->_G_getuid(ob);
}

nomask static void setuid() {
    if(!this_object()) return;
    uid = creator(this_object());
    GLOBAL->_G_setuid(this_object(),uid);
}

nomask static void export_uid(object ob) {
    if(geteuid() && !geteuid(ob)) GLOBAL->_G_setuid(ob,geteuid());
}

nomask static void export_euid(object ob) {
    if(geteuid() && !geteuid(ob)) GLOBAL->_G_seteuid(ob,geteuid());
}

