nomask static void seteuid(string str);
nomask static varargs string geteuid(object o);
nomask public varargs string getuid(object ob);
nomask static void setuid();
nomask static void export_euid(object ob);
