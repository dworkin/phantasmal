/*
 * LPMUD 3.x extentions and stuff that is not normally needed in the kernel
 * itself.
 */

# include <config.h>
# undef status
# include <status.h>
# include <limits.h>

# include "lp3sim.h"
# include "space.h"

# include "lp3sim.c"
# include "space.c"


private void initialize()
{
    INIT_LP3SIM();
}

/*
 * NAME:	_F_create()
 * DESCRIPTION:	initialize the object
 */
nomask void _F_create()
{
    rlimits (-1; -1) {
	initialize();
    }

    INIT_RESET();
}

