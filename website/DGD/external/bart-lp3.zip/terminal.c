private string _termtype;
private string _colour_enable;
private string _prompt;

nomask static void set_termtype(object player, string term, varargs string colour)
{
    if(player == this_object()) {
        _termtype = term;
        _colour_enable = colour;
    }
}

nomask static void set_prompt(object player, string prompt)
{
    if(player == this_object()) {
        _prompt = prompt;
    }
}

