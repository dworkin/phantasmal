#include "/kernel/include/sysprops.h"

private int reset_time;
private int auto_reset;

/*
 * NAME:	_F_reset0()
 * DESCRIPTION:	reset an object for the first time
 */
private void _F_reset0()
{
    object save_player;
    int t;

    debug_driver();
    debug_auto();
    _S_cloned_by(DRIVER->query_cloner());

    save_player = this_player();

    t = RESET_TIME * 50 + random(RESET_TIME * 20);
    reset_time = t + time();

    if (function_object("create", this_object()) != 0) {
        this_object()->create();
    } 

    if (function_object("reset", this_object()) != 0) {
	this_object()->reset(0);
    } 

    if(property("_p_o_debug_reset")) {
      DBT("_F_reset0(): t = "+t+", reset_time: "+ctime(reset_time)+"("+reset_time+")");
    }
    if(auto_reset || property(P_O_ALWAYS_RESET)) {
      call_out("do_reset",t);
      if(property("_p_o_debug_reset")) {
        DBT("call_out: "+t);
      }
    }
    set_this_player(save_player);
}

/*
 * NAME:	_F_reset()
 * DESCRIPTION:	reset an object, if it is time
 */
nomask void _F_reset()
{
    object save_player;
    int t;

    debug_driver();
    debug_auto();

    if (property(P_O_NO_RESET)) {
      if(property("_p_o_debug_reset")) DBT("P_O_NO_RESET\n");
      return;
    }

    if (reset_time <= time()) {
      t = RESET_TIME * 50 + random(RESET_TIME * 20);

      reset_time = time() + t;
      save_player = this_player();
      this_object()->reset(0);
      set_this_player(save_player);

      if(auto_reset || property(P_O_ALWAYS_RESET)) {
        call_out("do_reset",t);
      }

      if (function_object("reset", this_object()) != 0) {
          this_object()->reset(0);
      }

    } else {
      if(property("_p_o_debug_reset")) {
        DBT("reset skipped, reset_time > time()");
      }
    }
}

nomask void set_auto_reset(int flag) {
    if(flag) {
      add_property(P_O_ALWAYS_RESET);
    } else {
      remove_property(P_O_ALWAYS_RESET);
    }
}

void do_reset() {
  debug_driver();
  debug_auto();

  if(PRIVILEGED()) {
    if(property("_p_o_debug_reset")) DBT("do_reset in "+object_name(this_object()));
    _F_reset();
  } else if(property("_p_o_debug_reset")) DBT("illegal call to do_reset in "+
      object_name(this_object()));
}
