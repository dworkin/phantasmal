/*
 * Functionality for supporting the different APIs we support:
 *
 * DGD native (driver object)
 * DGD mixed (auto object, kernel)
 * LPMud compat (old 2.4.5 compat mode, tho with some 3.x functionality)
 * LPMud native (lpmud 3.x code)
 * 
 * The driver object will be DGD native automatically and needs no special
 * support here. For all other cases a mode can be set and if none is set
 * a default will be used based on the location of the object in the directory
 * tree as follows:
 *
 * DGD mixed    : everything in /kernel
 * LPMud native : objects outside /kernel that inherit /obj/Object.c
 * LPMud compat : all other objects
 *
 * Inherited objects normally use the mode of the object they are inherited
 * by, with exception of the auto object which always uses DGD mixed mode.
 */

#define M_NONE 0
#define M_DGD 1
#define M_MIXED 2
#define M_COMPAT 3
#define M_NATIVE 4

private int api;

nomask static int query_api() {
  if(api != M_NONE) return api;
  else {
    if(sscanf(file_name(this_object()),"/kernel/%*s") == 1) return M_MIXED;
    else if(inherits_file("/obj/Object",this_object())) return M_NATIVE;
    else return M_COMPAT;
  }
}

nomask static int set_api(int i) { api = i; }

