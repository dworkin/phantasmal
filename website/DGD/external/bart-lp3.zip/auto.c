/*
 * auto object for 2.4.5 mudlib
 */

# include <config.h>
# undef status
# include <status.h>
# include <limits.h>

#define DEBUGGER "aidil"
#define DBT(X) if(find_player(DEBUGGER)) find_player(DEBUGGER)->tell("DB: "+X+"\n")

# include "reset.h"
# include "privilege.h"
# include "creator.h"
# include "global.h"
# include "tool.h"
# include "array.h"
# include "light.h"
# include "living.h"
# include "inventory.h"
# include "interactive.h"
# include "file.h"
# include "mapping.h"
# include "call_out.h"
# include "simfun.h"
# include "strings.h"
# include "userids.h"
# include "lp3sim.h"
# include "properties.h"
# include "space.h"

# include "reset.c"
# include "creator.c"
# include "global.c"
# include "tool.c"
# include "array.c"
# include "light.c"
# include "living.c"
# include "inventory.c"
# include "interactive.c"
# include "file.c"
# include "mapping.c"
# include "call_out.c"
# include "simfun.c"
# include "terminal.c"
# include "strings.c"
# include "bitstring.c"
# include "userids.c"
# include "lp3sim.c"
# include "properties.c"
# include "space.c"


private void initialize()
{
    INIT_CREATOR();
    INIT_GLOBAL();
    INIT_TOOL();
    INIT_LIGHT();
    INIT_LIVING();
    INIT_INVENTORY();
    INIT_INTERACTIVE();
    INIT_FILE();
    INIT_MAPPING();
    INIT_CALL_OUT();
    INIT_SIMFUN();
    INIT_LP3SIM();
}

/*
 * NAME:	_F_create()
 * DESCRIPTION:	initialize the object
 */
nomask void _F_create()
{
    rlimits (-1; -1) {
	initialize();
    }

    INIT_RESET();
}

