private string new_function_exists(string name, int hide_static, object ob)
{
   string tmp;

   if(hide_static) {
      tmp = get_object("/std/obj/echo")->new_function_exists(name, ob);
      if(tmp && (tmp[0] != '/')) 
        tmp = "/" + tmp;
   }
   else
   {
      tmp = function_exists(name, ob);
      if(tmp && (tmp[0] != '/'))
         tmp = "/" + tmp;
   }
   return tmp;
}

private int valid_callback(string name)
{
   string res1, res2;
   object ob;

   res1 = new_function_exists(name, 0, this_object());
   res2 = new_function_exists(name, 1, this_object());
   if(res1 != res2)
   {
      if(ob = find_player("aidil"))
         ob->tell(sprintf("bugged callback %y %y %y %y\n", object_name(this_object()), name, res1, res2));
      error("Invalid callback argument\n");
      return 0;
   }
   return 1;
}

/*
// runtime checking of callback function
// May need more arguments in future
*/
private varargs mixed do_callback(string function, mixed arg1, mixed arg2, mixed arg3)
{
   string name;

   name = function[1..];
   valid_callback(name);

   /* if not valid, don't call function */
   return call_other(this_object(), name, arg1, arg2, arg3);
}
/*
 * support for properties, blatantly taken from KoBra's Object.c
 */

private mapping properties;

public varargs void add_property(string str, mixed val)
{
    if (!properties) properties = ([ ]);

    if(val && stringp(val) && (strlen(val) > 1) && (val[0] == '#'))
        valid_callback(val[1..]);

    properties[str] = val ? val : 1;
}

public varargs void set_properties(string *strs, mixed *vals)
{
    int i;

    if(!strs)
        return;
    properties = ([]);
    for (i = 0; i < sizeof(strs); i++)
        add_property(strs[i], vals ? vals[i] : 0);
}

public void remove_property(string str)
{
    if (properties)
        properties = m_delete(properties, str);
}

public mixed property(string str)
{
    return properties ? properties[str] : 0;
}

public mapping query_properties()
{
    return properties ? properties + ([ ]) : ([]);
}
