/*
 * NAME:	valid()
 * DESCRIPTION:	check if a path is valid
 */

#define ACCESS "/kernel/servers/access"

private string valid(string file, int type)
{
    object player;

    if (object_name(this_object()) == MASTER ||
        sscanf(object_name(this_object()),"/kernel/%*s") == 1) {
	return file;
    }

    player = this_player();
/*
    if (player == 0 || query_interactive(player) == 0) {
	return 0;
    }
    if(player) {
        file = (type == 0) ? player->valid_read(file) : player->valid_write(file);
    }
 
    if (!stringp(file)) {
	write("Bad file name."+typeof(file)+"\n");
	return 0;
    } else if (file != "" &&
	       (file[0] == '/' || sscanf(file, "%*s ") != 0 ||
	        sscanf(file, "%*s..") != 0)) {
	error("Illegal path: " + file);
    }
*/
    if(type  == 0) {
        if(is_player_object(this_object()) && 
            this_object()->query_real_name() 
        ) {
            return ACCESS->valid_user_read(
                file, 
                this_object()->query_real_name()
            );
        } else {
            return ACCESS->valid_object_read(
                file,
                ACCESS->getcuid(file_name(this_object()))
            );
        }
    } else {
        if(is_player_object(this_object()) &&
            this_object()->query_real_name() 
        ) {
            return ACCESS->valid_user_write(
                file,
                this_object()->query_real_name()
            );
        } else {
            return ACCESS->valid_object_write(
                file,
                ACCESS->getcuid(file_name(this_object()))
            );
        }
    }
    return file;
}

/*
 * NAME:	file_size()
 * DESCRIPTION:	get the size of a file
 */
static int file_size(string file)
{
    int *sizes;

    ARGCHECK(file, file_size, 1);
    if(object_name(this_object()) != "/kernel/servers/access") {
        file = valid(file, 0);
    }
    if (file == 0) {
	return -1;
    }
    sizes = ::get_dir(file)[1];
    if (sizeof(sizes) != 1) {
	return -1;
    }

    return sizes[0];
}

/*
 * NAME:	log_file()
 * DESCRIPTION:	log something
 */
static void log_file(string file, string str)
{
    int *sizes;

    ARGCHECK(file, log_file, 1);
    ARGCHECK(str, log_file, 2);

    if (sscanf(file, "%*s/") != 0 || strlen(file) > 30) {
	error("Illegal file name to log_file(" + file + ")");
    }
    file = "/log/" + file;
    sizes = ::get_dir(file)[1];
    if (sizeof(sizes) == 1 && sizes[0] >= LOG_FILE_SIZE) {
	::remove_file(file + ".old");
	::rename_file(file, file + ".old");
    }
    ::write_file(file, str);
}

/*
 * NAME:	get_dir()
 * DESCRIPTION:	get directory info
 */
static string *get_dir(string file)
{
    int len;

    ARGCHECK(file, get_dir, 1);
    file = valid(file, 0);
    if (file == 0) {
	return ({ });
    }

    len = strlen(file);
    if (file == "" || file[len - 1] == '/') {
	file += "*";
    } else if (len > 1 && file[len - 2 ..] == "/.") {
	file[len - 1] = '*';
    }
    return ::get_dir(file)[0];
}

/*
 * NAME:	mkdir()
 * DESCRIPTION:	make a directory
 */
static int mkdir(string file)
{
    ARGCHECK(file, mkdir, 1);
    file = valid(file, 0);
    return (file != 0 && ::make_dir(file) != 0);
}

/*
 * NAME:	make_dir()
 * DESCRIPTION:	make a directory
 */
static int make_dir(string file)
{
    return mkdir(file);
}

/*
 * NAME:	read_bytes()
 * DESCRIPTION:	read bytes from a file
 */
static varargs string read_bytes(string file, int start, int size)
{
    ARGCHECK(file, read_bytes, 1);
    file = valid(file, 0);
    if (file == 0) {
	return 0;
    }

    return ::read_file(file, start, size);
}

static string *explode_file(string file)
{
    string result;
    result = read_file(file);
    return explode(result,"\n");
}

/*
 * NAME:	read_lines()
 * DESCRIPTION:	return a line range of a file
 */
private string *read_lines(string file, int first, int num)
{
    int line, offset, size, *saved;
    string str, *lines;

    if (first < 0 || num < 0) {
	return 0;
    }

    if (first == 0) {
	first = 1;
    }
    line = 1;
    if (this_user()) {
	saved = this_user()->query_file_offset(file);
	if (saved != 0) {
	    line = saved[0];
	    if (line > 2 * first) {
		line = 1;
	    } else {
		offset = saved[1];
	    }
	}
    }

    for (;;) {
	if (line <= first) {
	    str = ::read_file(file, offset, FILE_CHUNK);
	    if (str == 0) {
		return 0;
	    }
	    lines = explode("\n" + str + "\n", "\n");
	    size = sizeof(lines) - 1;
	    if (line == first) {
		if (num == 0 || size < num) {
		    if (strlen(str) < FILE_CHUNK) {
			return lines;
		    }
		    error("Line range too large");
		}
	    }
	    if (size == 0) {
		if (strlen(str) < FILE_CHUNK) {
		    return 0;
		}
		error("Line too long");
	    }
	} else {
	    offset -= FILE_CHUNK;
	    if (offset < 0) {
		offset = 0;
	    }
	    str = ::read_file(file, offset, FILE_CHUNK);
	    if (str == 0) {
		return 0;
	    }
	    lines = explode("\n" + str + "\n", "\n");
	    size = sizeof(lines) - 1;
	    if (offset == 0) {
		line = 1;
	    } else {
		if (size == 0) {
		    error("Line too long");
		} else {
		    --size;
		    line -= size;
		    if (line <= 0) {
			/* ??? */
			line = 1;
			offset = 0;
			continue;
		    }
		    offset += strlen(lines[0]) + 1;
		    lines = lines[1 ..];
		}
	    }
	}

	if (line <= first && line + size > first) {
	    if (num != 0 && line + size >= first + num) {
		first -= line;
		if (this_user() != 0) {
		    line += first + num;
		    offset += strlen(implode(lines[0 .. first + num - 1],
				     "\n")) + 1;
		    this_user()->set_file_offset(file, line, offset);
		}
		return lines[first .. first + num - 1] + ({ "" });
	    }
	    size = first - line;
	}
	if (line < first) {
	    line += size;
	    offset += strlen(implode(lines[0 .. size - 1], "\n")) + 1;
	}
    }
}

/*
 * NAME:	read_file()
 * DESCRIPTION:	read a file
 */
static varargs string read_file(string file, int first, int num)
{
    string *lines;

    ARGCHECK(file, read_file, 1);
    file = valid(file, 0);
    if (file == 0) {
	return 0;
    }

    if (first == 0 && num == 0) {
	return ::read_file(file);
    }

    lines = read_lines(file, first, num);
    if (lines == 0) {
	return 0;
    }
    return implode(lines, "\n");
}

/*
 * NAME:	rm()
 * DESCRIPTION:	remove a file
 */
static int rm(string file)
{
    ARGCHECK(file, rm, 1);
    file = valid(file, 1);
    return (file != 0 && ::remove_file(file));
}

/*
 * NAME:	remove_file()
 * DESCRIPTION:	remove a file
 */
static int remove_file(string file)
{
    return rm(file);
}

/*
 * NAME:	rmdir()
 * DESCRIPTION:	remove a directory
 */
static int rmdir(string file)
{
    ARGCHECK(file, rmdir, 1);
    file = valid(file, 1);
    return (file != 0 && ::remove_dir(file));
}

/*
 * NAME:	remove_dir()
 * DESCRIPTION:	remove a directory
 */
static int remove_dir(string file)
{
    return rmdir(file);
}

/*
 * NAME:	rename()
 * DESCRIPTION:	rename a file
 */
static int rename(string from, string to)
{
    ARGCHECK(from, rename, 1);
    ARGCHECK(to, rename, 2);

    from = valid(from, 1);
    if (from == 0) {
	return 0;
    }
    to = valid(to, 1);
    if (to == 0) {
	return 0;
    }
    if(file_size(to) >= 0) rm(to);
    return ::rename_file(from, to);
}

/*
 * NAME:	rename_file()
 * DESCRIPTION:	rename a file
 */
static int rename_file(string from, string to)
{
    return rename(from, to);
}

/*
 * NAME:	restore_object()
 * DESCRIPTION:	restore an object
 */
static int restore_object(string file)
{
    string str, *path;

    ARGCHECK(file, restore_object, 1);

    if (this_object() == 0) {
	return 0;
    }
    if (sscanf(file, "%*s/../") != 0) {
	error("Illegal restore file name " + file);
    }
    path = explode(object_name(this_object()), "/");
    switch (path[0]) {
    case "players":
/*
	if (sscanf(file, "players/%s/", str) == 0 || str != path[1] ||
	    sscanf(file, "%*s.") != 0) {
	    error("Illegal restore file name " + file);
	}
*/
	break;

    case "obj":
    case "room":
    case "std":
    case "daemon":
    case "kernel":
	break;

    default:
	error("Illegal use of restore_object(), path element = "+path[0]);
    }
    return ::restore_object(file + ".o");
}

/*
 * NAME:	save_object()
 * DESCRIPTION:	save an object
 */
static void save_object(string file)
{
    string str, *path;

    ARGCHECK(file, save_object, 1);

    if (this_object() == 0) {
	return;
    }
    if (sscanf(file, "%*s/../") != 0) {
	error("Illegal save file name " + file);
    }
    path = explode(object_name(this_object()), "/");
/*
    switch (path[0]) {
    case "players":
	if (sscanf(file, "players/%s/", str) == 0 || str != path[1] ||
	    sscanf(file, "%*s.") != 0) {
	    error("Illegal save file name " + file);
	}
	break;

    case "obj":
    case "room":
    case "std":
	break;

    default: break;
	error("Illegal use of save_object()");
    }
*/
    ::save_object(file + ".o");
}

/*
 * NAME:	write_bytes()
 * DESCRIPTION:	write bytes to file
 */
static int write_bytes(string file, int start, string str)
{
    int *sizes;

    ARGCHECK(file, write_bytes, 1);
    ARGCHECK(str, write_bytes, 2);

    file = valid(file, 1);
    if (file != 0) {
	if (start == 0) {
	    sizes = ::get_dir(file)[1];
	    if (sizeof(sizes) == 1) {
		start = -sizes[0];
	    }
	}
	return ::write_file(file, str, start);
    }
    return 0;
}

/*
 * NAME:	write_file()
 * DESCRIPTION:	write string to file
 */
static int write_file(string file, string str)
{
    ARGCHECK(file, write_file, 1);
    file = valid(file, 1);
    return (file != 0 && ::write_file(file, str));
}

/*
 * NAME:	cat()
 * DESCRIPTION:	show a file
 */
static varargs int cat(string file, int first, int num)
{
    string *lines;

    ARGCHECK(file, cat, 1);
    file = valid(file, 0);
    if (file == 0) {
	return 0;
    }

    if (num == 0) {
	num = CAT_LINES + 1;
    }
    lines = read_lines(file, first, num);
    if (lines == 0) {
	return 0;
    }

    if (sizeof(lines) <= CAT_LINES + 1) {
	write(implode(lines, "\n"));
    } else {
	write(implode(lines[0 .. CAT_LINES - 1], "\n") +
	      "\n***TRUNCATED***\n");
    }
    return 1;
}

/*
 * NAME:	tail()
 * DESCRIPTION:	show the tail of a file
 */
static int tail(string file,varargs int len, int t_lines)
{
    int size, *sizes;
    string str, *lines;

    ARGCHECK(file, tail, 1);
    file = valid(file, 0);
    if (file == 0) {
	return 0;
    }

    if(!len) len = TAIL_CHUNK;
    if(!t_lines) t_lines = TAIL_LINES;
    sizes = ::get_dir(file)[1];
    if (sizeof(sizes) == 1) {
	size = len;
	for (;;) {
	    if (size > sizes[0]) {
		size = sizes[0];
	    }

	    str = ::read_file(file, -size, size);
	    if (str == 0 || strlen(str) != size) {
		return 0;
	    }
	    lines = explode("\n" + str + "\n", "\n");

	    if (sizeof(lines) >= t_lines + 1 || size == sizes[0]) {
		if ((size=sizeof(lines)) > t_lines + 1) {
		    str = implode(lines[size - t_lines - 1 ..], "\n");
		} else {
		    sscanf(str, "%*s\n%s", str);
		}
		write(str);
		return 1;
	    }
	    size += len;
	}
    }
    return 0;
}

/*
 * NAME:	editor()
 * DESCRIPTION:	handle an editor command
 */
static string editor(string cmd)
{
    string fname;

    fname = explode(object_name(this_object()), "#")[0];
    if (fname != EDITOR && fname != CINDENT) {
	error("Illegal call to editor()");
    }
    if (cmd == 0) {
	return ::editor();
    } else {
	return ::editor(cmd);
    }
}

/*
 * NAME:	ed()
 * DESCRIPTION:	start an editor session
 */
static varargs void ed(string file, string exit_func)
{
    object user, editor;

    if (this_player() == 0) {
	return;
    }
    if ((user=query_interactive(this_object())) == 0) {
	error("Tried to start an ed session on a non-interactive player");
    }
    if (this_player() != this_object()) {
	error("Illegal start of ed");
    }

    editor = user->query_editor();
    if (editor != 0) {
	error("Tried to start an ed session, when already active");
    }
    rlimits (-1; -1) {
	editor = clone_object(EDITOR);
	user->set_editor(editor, exit_func);
    }

    if (file == 0) {
	editor->edit();
    } else {
	editor->edit("e /" + file);
    }
}

/*
 * NAME:	cindent()
 * DESCRIPTION:	indent an LPC file
 */
static int cindent(string file)
{
    return clone_object(CINDENT)->indent(file);
}

/*
 * NAME:	ls()
 * DESCRIPTION:	write a directory listing
 */
static int ls(string file)
{
    mixed *dir;
    string *list, str, dirlist;
    int *sizes, i, j, sz, max, rows;

    ARGCHECK(file, ls, 1);
    file = valid(file, 0);
    if (file == 0) {
	return 0;
    }

    i = strlen(file);
    if (file == "" || file[i - 1] == '/') {
	file += "*";
    } else if (i > 1 && file[i - 2 ..] == "/.") {
	file[i - 1] = '*';
    }
    dir = ::get_dir(file);
    list = dir[0];
    if (sizeof(list) == 0) {
	return 0;
    }

    for (i = 0, sz = sizeof(list); i < sz; i++) {
	j = strlen(list[i]);
	if (j > max) {
	    max = j;
	}
    }
    max++;
    j = 80 / (max + 1);
    rows = sz / j;
    if (sz % j > 0) {
	rows++;
    }

    dirlist = "";
    sizes = dir[1];
    for (i = 0; i < rows; i++) {
	j = i;
	for (;;) {
	    str = list[j];
	    if (sizes[j] < 0) {
		str += "/";
	    }
	    j += rows;
	    if (j >= sz) {
		dirlist += str + "\n";
		break;
	    }
	    dirlist += (str + "                                        ")
		       [0 .. max];
	}
    }
    write(dirlist);

    return 1;
}

nomask static int file_time(string file) {
    if(!valid(file, 0)) return -1;
    /* bogus implementation */
    return 0;
}


/*
 * NAME:        copy()
 * DESCRIPTION: copy a file (DGD doesn't have something like this? I wonder)
 *              this function needs to be reviewed, there should be a driver
 *              level equivalent for this really.
 *              also, note that this code for now lacks any access checks, 
 *              it completely relies on access checks in read/write_bytes
 *              and just assumes all works.
 */
#define CHUNKSIZE 2048
nomask static int copy(string file1, string file2) {
    int f_size;
    int chunk;
    int num_chunks;
    int remain;
    string buffer;
    
    if(file1 == file2) error("Cannot copy file over itself");
    f_size = file_size(file1);
    if(f_size < 1) error("File "+file1+" does not exist");
    num_chunks = f_size/CHUNKSIZE;
    remain = f_size - (num_chunks * CHUNKSIZE);

    rm(file2);
    for(chunk = 0; chunk < num_chunks; chunk++) {
        buffer = read_bytes(file1, (chunk * CHUNKSIZE), CHUNKSIZE);
        write_bytes(file2, (chunk * CHUNKSIZE), buffer);
    }
    if(remain) {
        buffer = read_bytes(file1, (chunk * CHUNKSIZE), remain);
        write_bytes(file2, (chunk * CHUNKSIZE), buffer);
    }
    return 1;
}
#undef CHUNKSIZE

#define ALT_FILE_LINES
#ifndef ALT_FILE_LINES
nomask static int file_lines(string file) {
  string * data;
  int count;
  int pos;
  int lastcount;

  file = valid(file,0);
  if(!file || (file_size(file) < 0)) return -1;

  pos = 1;
  /* This needs a lot of time... this function is very stupid, and should
   * either go into the driver itself (in c it will be a lot faster) or
   * should go in a precompiled lpc object that is linked to the driver
   * (still a lot faster then this but less optimal then a real c version)
   */
  do {
      data = read_lines(file,pos,50);
      if(data) count += sizeof(data);
      pos += 51;
  } while (data && sizeof(data) == 51);
  return count-1;
}
#else
#define CHUNKSIZE 65535
nomask static int file_lines(string file) {
    int f_size;
    int chunk;
    int num_chunks;
    int remain;
    string buffer;
    int count;
    int pos;

    ARGCHECK(file, file_lines, 1);
    file = valid(file, 0);
    if(!file) return -1;
    f_size = file_size(file);
    if(f_size < 0) return -1;
    num_chunks = f_size/CHUNKSIZE;
    remain = f_size - (num_chunks * CHUNKSIZE);
    if(remain) num_chunks++;
    for(chunk = 0; chunk < num_chunks; chunk++) {
        buffer = read_bytes(file, (chunk * CHUNKSIZE), CHUNKSIZE);
        for(pos = 0; pos < strlen(buffer); pos++) {
            if(buffer[pos] == '\n') count++;
        }
        /* count += sizeof(explode(buffer,"\n")); */
    }
    if(buffer[strlen(buffer)-1] != '\n') count++;
    return count;
}
#endif
