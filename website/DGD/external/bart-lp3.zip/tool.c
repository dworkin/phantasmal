/*
 * NAME:	badarg()
 * DESCRIPTION:	cause a bad argument error
 */
private void badarg(string func, int arg)
{
    error("Bad argument " + arg + " to function " + func);
}

/*
 * NAME:	capitalize()
 * DESCRIPTION:	capitalize a string
 */
static string capitalize(string str)
{
    ARGCHECK(str, capitalize, 1);

    if(str == "") return "";
    if (str[0] >= 'a' && str[0] <= 'z') {
	str[0] -= 'a' - 'A';
    }
    return str;
}

/*
 * NAME:	lower_case()
 * DESCRIPTION:	convert a string to lower case
 */
static string lower_case(string str)
{
    int i, len, c;

    ARGCHECK(str, lower_case, 1);

    for (i = 0, len = strlen(str); i < len; i++) {
	c = str[i];
	if (c >= 'A' && c <= 'Z') {
	    str[i] += 'a' - 'A';
	}
    }
    return str;
}

/*
 * NAME:	set_bit()
 * DESCRIPTION:	set a bit in a bit string
 */
static string set_bit(string str, int bit)
{
    int ind, len, c;

    ARGCHECK(str, set_bit, 1);

    if (bit > MAX_BITS) {
	error("Too big bit number " + bit);
    }
    ind = bit / 6;
    len = strlen(str);
    if (ind >= len) {
	do {
	    str += "                    ";
	    len += 20;
	} while (ind >= len);
	str = str[0 .. ind];
    }
    c = str[ind];
    if (c < ' ') {
	error("Illegal bit pattern in character " + ind);
    }
    str[ind] = (c - ' ' | 1 << bit % 6) + ' ';

    return str;
}

/*
 * NAME:	clear_bit()
 * DESCRIPTION:	clear a bit in a bit string
 */
static string clear_bit(string str, int bit)
{
    int ind, c;

    ARGCHECK(str, clear_bit, 1);

    if (bit > MAX_BITS) {
	error("Too big bit number " + bit);
    }
    ind = bit / 6;
    if (ind >= strlen(str)) {
	return str;
    }
    c = str[ind];
    if (c < ' ') {
	error("Illegal bit pattern in character " + ind);
    }
    str[ind] = (c - ' ' & ~(1 << bit % 6)) + ' ';

    return str;
}

/*
 * NAME:	test_bit()
 * DESCRIPTION:	test a bit in a bit string
 */
static int test_bit(string str, int bit)
{
    int ind;

    ARGCHECK(str, test_bit, 1);

    ind = bit / 6;
    if (ind >= strlen(str)) {
	return 0;
    }

    return (str[ind] - ' ' & 1 << bit % 6) != 0;
}

/*
 * NAME:	extract()
 * DESCRIPTION:	extract a substring
 */
static varargs string extract(string str, int first, int last)
{
    ARGCHECK(str, extract, 1);

    /* will mistake extract(str, 0) for extract(str, 0, 0) */

    if (first >= strlen(str)) 
        first = strlen(str) -1;

    if (last >= strlen(str)) 
        last = strlen(str) -1;

    if (last < 0) 
        last = strlen(str)+last;

    if (first < 0) 
        first = strlen(str)+first;

    if(last < 0) 
        last = 0;

    if(first < 0) 
        first = 0;

    if (first != 0 && last == 0) {
	last = strlen(str) - 1;
    } else if (first >= strlen(str) || last < first || last > strlen(str)) {
	return "";
    }

    return str[first .. last];
}
