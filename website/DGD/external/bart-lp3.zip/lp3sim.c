/*
 * This file implements most of the 3.x and Kobra extentions to the original
 * lpmud gamedriver.
 * it includes many extentions from lpmud 3.x, and many string functions
 * not present in the DGD driver.
 * To actually run code from Kobra, you will have to make some small
 * changes to your code. Most importantly, sprintf is not there. When
 * needed, you can use an external library provided in 
 * /kernel/lib/extra/Sprintf/sprintf.c
 * Also, you need to be explicit about the locations of any inherited 
 * files and files you try to load etc.
 *
 * Aidil of The Way of the Force, august 2003.
 *
 */

#define DEBUGGER "aidil"
#define DBT(X) if(find_player(DEBUGGER)) find_player(DEBUGGER)->tell("DB: "+X+"\n")

private int _is_native;    /* lpmud 3.x compat/native mode flag */
private int _dgd_overide;  /* overide to force dgd kernel mode  */
private int _is_hardinvis; /* is this object hard invisible?    */
private int _see_hinvis;   /* can we see hinvis objects?        */
private object _cloned_by; /* which object cloned this object?  */
private varargs int _non_compat(object obj);

/*
 * NAME:        INIT_LP3SIM()
 * DESCRIPTION: Initialize the emulator, sets default object behavior.
 */
private INIT_LP3SIM() {
    _dgd_overide = 0;
    if(!dgd_native())
        _is_native = _non_compat(this_object());
}

nomask static object compile_object(string f) {
    if(sscanf(previous_program(),"/kernel/%*s") != 1) return 0;
    return DRIVER->do_compile(f);
}

/*
 * NAME:        is_player_object()
 * DESCRIPTION: check if current object is a player object
 */
nomask static int is_player_object(object obj)
{
    int r;
    ARGCHECK(obj, is_player_object, 1);
    r = member_array(PLAYER+".c",inherit_list(obj));
    if(r == -1) {
        return 0;
    } else {
        return 1;
    }
}
/*
    if(non_compat(this_object())) {
        return (file_name(obj) == "/obj/player") || 
               (file_name(obj) == "/std/player/logon");
    } else {
        return (file_name(obj) == "obj/player") ||
               (file_name(obj) == "std/player/logon");
    }
}
*/

/*
 * NAME:        call_until()
 * DESCRIPTION: call function in elements of an array untill n non zero values
 */
static int call_until(mixed *arr, string fun, int n,varargs mixed a1,mixed a2,mixed a3,mixed a4)
{
    int m;
    int count;
    if(!n) error("Invalid number for call_until");
    if(!fun || fun == "") error("Empty function name in call_until");

    for(count = 0; count < sizeof(arr) && m < n; count++)
    {
        object ob;
        if(stringp(arr[count]))
        {
            ob = get_object(arr[count]);
        } else if(objectp(arr[count])) {
            ob = arr[count];
        } else {
            error("invalid element in array for call_until");
        }
        if(call_other(ob,fun,a1,a2,a3,a4))
        {
            m++;
        }
    }
    if(m == n) return m;
    else return -(1+m);
}

/*
 * NAME:        original()
 * DESCRIPTION: 1 on master, 0 on clone
 */
nomask static int original()
{
    string f;
    f = file_name(this_object());
    if(f[0] != '/') f = "/"+f;

    if(get_object(f) == this_object()) {
       return 1;
    } else {
       return 0;
    }
}
/*
 * NAME:        call_array()
 * DESCRIPTION: call fun in all elements of the array
 */
nomask static mixed * call_array(mixed *arr, string fun, varargs mixed a1, mixed
 a2, mixed a3, mixed a4, mixed a5)
{
    mixed * result;
    object obj;
    int count;
    result = ({});
    for(count = 0; count < sizeof(arr); count++) {
      switch(typeof(arr[count])) {
        case "string" : obj = get_object(arr[count]);
                        break;
        case "object" : obj = arr[count];
                        break;
        default       : error("Invalid element ["+count+"] in array for call_array");
                        return 0;
                        break;
      }
      result += ({call_other(obj,fun,a1,a2,a3,a4,a5)});
    }
    return result;
}

/*
 * NAME:        this_interactive()
 * DESCRIPTION: return the current interactive user
 */
nomask static object this_interactive() {
#ifdef OLD_THIS_INTERACTIVE
    return GLOBAL->query_this_interactive();
#else
    return this_user() ? this_user()->query_player() : 0;
#endif
}

/* 
 * NAME:        make_skip_array()
 * DESCRIPTION: private function for call/tell_array and tell_env 
 */
private object *make_skip_array(mixed skip)
{
    if (!skip) {
        return ({});
    } else if (!pointerp(skip)) {
        if (!objectp(skip)) {
            return ({});
        } else {
            return ({skip});
        }
    } else {
        return skip;
    }
}

/*
 * NAME:        tell_env()
 * DESCRIPTION: tell message to all objects (minus skip) in the env of ob
 */
nomask static void tell_env(object ob, string msg, varargs mixed skip)
{
    object env;
    object * targets;
    int count;
    env = environment(ob);
    if(!env) return;
    targets = all_inventory(env);
    skip = make_skip_array(skip);
    if(sizeof(skip))
        targets -= skip;
    targets -= ({ob});
    call_array(targets, "tell", msg);
}

/*
 * NAME: 
 * DESCRIPTION: tell msg to an array of objects.... why is this utter
 * trivial thing an efun on kobra?? oh wait, its a simulated efun.. 
 * oh well, its so trivial that its still nonsense that it exists
 */
nomask static void tell_array(object * ob, string msg, varargs mixed skip)
{
    object * targets;
    targets = ob;
    skip = make_skip_array(skip);
    if(sizeof(skip))
        targets -= skip;
    call_array(targets,"tell",msg);
}

nomask static void tell_inv(object ob, string msg, varargs mixed skip)
{
    object * targets;
    targets = all_inventory(ob);
    skip = make_skip_array(skip);
    if(sizeof(skip))
    targets -= skip;
    call_array(targets,"tell",msg);
}

nomask static void tell_all_room(string message, varargs mixed skip) {
    object ob;
    ob = this_object();
    if(!environment(ob)) return;

    /* EEP, this will messup with our planned universe setup.. */
    while(environment(ob) && environment(environment(ob))) {
        ob = environment(ob);
    }
    tell_inv(environment(ob),message,skip);
}
   

/* 
 * NAME:        call()
 * DESCRIPTION: call a function in this_object()
 */
nomask static mixed call(string fun, varargs mixed a1, mixed a2, mixed a3, mixed a4, mixed a5)
{
    return call_other(this_object(),fun,a1,a2,a3,a4,a5);
}

/*
 * NAME:        master_object()
 * DESCRIPTION: return the master_object
 */
nomask static object master_object()
{
    return get_object(MASTER);
}

/*
 * NAME:        stat_object()
 * DESCRIPTION: return the stat object
 */
nomask static object stat_object()
{
    return get_object("/obj/stat");
}

/*
 * NAME:        universe()
 * DESCRIPTION: return the universe object
 */
nomask static object universe()
{
    return get_object("/kernel/servers/universe");
}

/*
 * NAME:        non_compat()
 * DESCRIPTION: Everything should be considered 'non compat'
 */
nomask static varargs int non_compat(object obj) {
    if(!obj) obj = this_object();
    return obj->_Q_non_compat();
}

nomask public int _Q_non_compat() {
  if(PRIVILEGED())
    return _is_native; 
}

private varargs int _non_compat(object obj)
{
    int i;
    if(!obj) obj = this_object();
    if(inherit_list(obj)) {
        i = member_array("/std/Object.c",inherit_list(obj));
    } else {
        i = -1;
    }

    if(i < 0)
        return 0;
    return 1;
}

/*
 * NAME:        dgd_native()
 * DESCRIPTION: Are we a simulated Kobra object or a DGD kernel object..
 */
nomask static varargs int dgd_native(object ob)
{
    if(!ob) ob = this_object();
    if(ob->_Q_dgd_overide()) return 1;
    return (object_name(ob)[0..7] == "/kernel/");
}

nomask public int _Q_dgd_overide() { return _dgd_overide; }

nomask public void set_hard_invis(varargs object o, int flag) 
{
    object p;

    if(o && o != this_object()) 
        return;
    p = previous_object();
    if(p && p == o && is_player_object(o) && o->query_arch())
        _is_hardinvis = flag;
    else
        write_file("/log/admin/hinvis_fail","Illegal call to set_hard_invis()");
}

nomask public int query_hard_invis() {
    object o;
    o = this_object();
    if(is_player_object(o) && o->query_arch())
        return _is_hardinvis;
}

nomask static void set_see_hinvis(object o, int flag)
{
    /* do nothing since we don't have hinvis (yet) */
}

nomask static void remove_action(string verb, varargs object player)
{
    object e1, e2;
/*
    ARGCHECK(func && function_object(func, this_object()) != AUTO,
             add_action, 1);
*/
    if(!player || !is_player_object(player))
        player = this_player();
    if (player == 0) {
        return;
    }
    if (this_object() != player && (e1=environment()) != player &&
        e1 != (e2=environment(player)) && this_object() != e2) {
        error("remove_action from object that was not present");
    }
    rlimits (-1; -1) {
        player->_F_remove_action(this_object(), verb);
    }
}

nomask void dump_all_objects(varargs string f) { /* does nothing yet */ }
nomask static string * inherit_list(object o) {
    string f;
    string * fnames;

    if(!o) 
        error("Invalid argument 1 to inherit_list");

    f = file_name(o);
    if(f[0..0] != "/") f = "/"+f;
    fnames = (string *) GLOBAL->_Q_inherit_list(f);
    if(!fnames) {
        fnames = ({});
    }
    return fnames;
}

nomask mapping add_mapping(mapping m1, mapping m2)
{
    int pos;
    mixed * indices;
    mapping result;

    result = m1 + ([]);
    indices = m_indices(m2);

    if(sizeof(indices)) {
        for(pos = 0; pos < sizeof(indices); pos++ ) {
            result[indices[pos]] = m2[indices[pos]];
        }
    }
    return result;
}

nomask void _S_cloned_by(object ob) {
  _cloned_by = ob;
}

nomask static object _Q_cloned_by() {
  return _cloned_by;
}

nomask static void _S_emulation(string mode) {
    ARGCHECK(stringp(mode),"_S_set_emulation",1);
    mode = lower_case(mode);
    switch(mode) {
        case "native" : _is_native = 1;
                        _dgd_overide = 0;
                        break;
        case "compat" : _is_native = 0;
                        _dgd_overide = 0;
                        break;
        case "dgd"    : _dgd_overide = 1;
                        break;
        default       : error("No such emulation mode "+mode+".");
                        break;
    }
}

nomask static varargs int uptime (int flag) {
  mixed * s_info;

  s_info = status();
  if(flag) 
    return time() - s_info[ST_STARTTIME];
  else
    return s_info[ST_UPTIME];
}

nomask static varargs int get_mem_usage (int flag) {
  mixed * s_info;

  s_info = status();
  if(flag) 
    return s_info[ST_SMEMUSED] + s_info[ST_DMEMUSED];
  else
    return s_info[ST_SMEMSIZE] + s_info[ST_DMEMSIZE];
}
 
nomask mixed typeof(mixed arg) {
    int n;

    n = ::typeof(arg);
    switch(n) {
        case T_INT     : return "int"; break;
        case T_STRING  : return "string"; break;
        case T_ARRAY   : return "array"; break;
        case T_MAPPING : return "mapping"; break;
        case T_OBJECT  : return "object"; break;
        default        : return "unknown"; break;
    }
}

nomask int _typeof(mixed arg) {
  return ::typeof(arg);
}

nomask static object compile(mixed o, varargs object io) {
    object ob;
    string err;
    int recompile;

    if(previous_program() != COMPILERLIB && 
       previous_program() != AUTO
    ) return 0;

    ARGCHECK(o, compile, 1);

    if(io) {
        DRIVER->set_inform_compile(io);
    }
    if(objectp(o)) {
        recompile = 1;
        err = catch(ob = compile_object(file_name(o)));
    } else if(stringp(o)) {
        if(find_object(o)) recompile = 1;
        err = catch(ob = compile_object(o));
    }
    if(ob && !err) err = catch(ob->_F_recompiled(object_name(ob),recompile));
    DRIVER->set_inform_compile(0);
    if(err) error(err);
    return ob;
}

nomask static void debug_driver() {
    DRIVER->set_debug_driver(1);
}

nomask static void debug_auto() {
    DRIVER->set_debug_auto(1);
}

nomask static void debug_user() {
    DRIVER->set_debug_user(1);
}

nomask static void _F_recompiled(string o, int flag) { 
    if(this_object() && function_object("recompiled",this_object()) == o) {
        call("recompiled",flag);
    }
}

nomask static void register_inherit_by(string file, string ob) {
    write_file("/log/inh",ob+" inherited "+file+"\n");
}

nomask static void show_prompt() {
    if(this_user()) this_user()->do_show_prompt();
}

nomask static string * query_action_verbs(object ob, object player) {
    return player->_Q_action_verbs(ob)+({});
}

