public varargs void add_property(string str, mixed val);
public varargs void set_properties(string *strs, mixed *vals);
public void remove_property(string str);
public mixed property(string str);
public mapping query_properties();
