#pragma save_types

private mapping watched_events;

nomask varargs void signal_event(string event, mixed args);
nomask void add_event_observer(mixed event, mixed observer);
nomask void remove_event_observer(mixed event, mixed observer);
nomask varargs mixed query_event_observers(string event, string euid);

nomask varargs void signal_event(string event, mixed args)
{
   mixed *watchers;
   string str;
   int i;

   if (!watched_events || !m_sizeof(watched_events))
      return;
   if (watchers = watched_events[event])
   {
      if(pointerp(watchers) && sizeof(watchers))
      {
         watchers -= ({ 0 });
         watched_events[event] = watchers;
         for(i=sizeof(watchers)-1; i>=0; i--)
         {
             str = catch(watchers[i]->notify_event(event, args));
             if(str) {}
         }
      }
   }
}

/*
 * add an object that wants to be informed of events that occur to this object
 * - event can be one event, or an array of events
 * - observer can be a string or an object
 */
nomask void add_event_observer(mixed event, mixed observer)
{
   mixed *watchers;

   if (!watched_events) watched_events = ([]);
   if (!objectp(observer) && !stringp(observer))
      return;

   if (stringp(observer) && catch(get_object(observer)))
      return;

   if (pointerp(event))
   {
      filter_array(event, "add_event_observer", this_object(), observer);
      return;
   }
   if (!(watchers = watched_events[event]))
      watchers = ({});
   if (member_array(observer, watchers) != -1)
      return;
   watchers += ({ observer });
   watched_events[event] = watchers;
}

nomask void remove_event_observer(mixed event, mixed observer)
{
   mixed *watchers;

   if (pointerp(event))
   {
      filter_array(event, "remove_event_observer", this_object(), observer);
      return;
   }
   if (!(watchers = watched_events[event]))
      return;
   watchers -= ({ observer });
   if (sizeof(watchers))
      watched_events[event] = watchers;
   else
      watched_events = m_delete(watched_events, event);
}

/* This query function should be removed when the new player is working */

nomask varargs mixed query_event_observers(string event, string euid)
{
   if (event)
      return watched_events[event];
   else
      return watched_events + ([]);
}
