private void init_creator();

static string creator(object obj);

# define INIT_CREATOR()	init_creator()
