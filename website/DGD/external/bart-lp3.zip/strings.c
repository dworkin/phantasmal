nomask static string delete(string str, int from, varargs int to)
{
    string result;
    int len;
    ARGCHECK(str,"delete",1);
    ARGCHECK(intp(from),"delete",2);

    len = strlen(str);

    if(from < 0) 
        from = len + from;
    if(to < 0) 
        to = len + to;
    if(to == 0) 
        to = from;

    if(to >= len) to = len -1;
    if(from >= len || from < 0)  {
        result = "";
    } else if(to < from ) {
        result = "";
    }
    else {
        result = "";
        if(from > 0) 
            result += str[0..from-1];
        if(to+1 < len) 
            result += str[to+1..];
    }
    return result;
}

nomask static string strallsub(string str, string old, string new)
{
    int pos;
    int len;
    string result;
    ARGCHECK (stringp(str),"strallsub",1);
    ARGCHECK (stringp(old),"strallsub",2);
    ARGCHECK (stringp(new),"strallsub",3);

    if(str == "") return "";
    len = strlen(old)-1;
    if(len > strlen(str)-1) return str;
    result = "";
    for(pos = 0; pos < strlen(str); pos++) {
        if(pos+len < strlen(str) && str[pos..pos+len] == old) {
            result += new;
            pos += len;
        } else {
            result += str[pos..pos];
        }
    }
    return result;
}

/*
 * NAME:        strstr()
 * DESCRIPTION: return a substring from s1, starting with s2
 */
nomask static string strstr(string s1, string s2)
{
    int pos;
    int len;
    len = strlen(s2)-1;
    if(len > strlen(s1)-1) return 0;
    for(pos = 0; pos < (strlen(s1)-len); pos++) {
        if(s1[pos..pos+len] == s2) {
          return s1[pos ..];
        }
    }
    return 0;
}

nomask static string break_string(string str, int len, varargs mixed ident)
{
    int pos;
    string result;
    result = "";
    for(pos = 0; pos < strlen(str); pos += len) {
        if(ident) {
            if(intp(ident)) result += "                                                                                "[0..ident-1];
            else if(stringp(ident)) result += ident;
        }
        if(pos+len<strlen(str))
            result += str[pos..pos+len];
        else
            result += str[pos ..];
        result += "\n";
    }
    return result;
}

nomask static string strsub(string str, string old, string new)
{
    int pos;
    int len;
    string result;
    len = strlen(old)-1;
    if(len > strlen(str)-1) return str;
    result = str;
    for(pos = 0; pos < (strlen(str)-len); pos++) {
        if(str[pos..pos+len] == old) {
            if(!pos) 
                result = new;
            else
                result = str[0..pos-1]+new;
            if(pos+len+1 < strlen(str)) result += str[pos+len+1 ..];
            break;
        }
    }
    return result;
}

nomask static int strcpos(string str, int c)
{
    int pos, len;
    ARGCHECK(stringp(str),"strcpos",1);
    ARGCHECK(intp(c),"strcpos",2);
    len = strlen(str);
    for(pos = 0; pos < len; pos++) {
        if(str[pos] == c) return pos;
    }
    return -1;
}

nomask static int strstrpos(string str, string substr)
{
    int pos, len, sublen;
    len = strlen(str);
    sublen = strlen(substr)-1;
    for(pos = 0; pos < (len-sublen); pos++) {
        if(str[pos..pos+sublen] == substr) return pos;
    }
    return -1;
}

nomask static string readable_string(string str)
{
    return str;
}

/* lol, this is almost a copy/paste of the c code.
 * gotta love DGD for being able to access chars in a string ;)
 */
nomask static int strncmp(string s1, string s2, int n)
{
    int l1,l2,x,result;

    l1 = strlen(s1); 
    l2 = strlen(s2);
    result = 0;
    for(x = 0; x < n; x++) {
        int val1, val2;
        if(x<l1) 
            val1 = s1[x];
        else 
            val1 = 0;
        if(x<l2) 
            val2 = s2[x];
        else
            val2 = 0;

        result = val1 - val2;
        if(result != 0) return result;
    }
    return result;
}

nomask static int strrcpos(string str, int c)
{
    int len;
    int pos;

    len = strlen(str)-1;
    for(pos = len; pos >= 0; pos--) {
        if(str[pos] == c) {
            return pos;
        } else { 
        }
    }
    return -1;
}

nomask static int strcsetpos(string str, string set) {
    int pos;
    int len;
    int set_pos;
    int set_len;

    len = strlen(str);
    set_len = strlen(set);
    if(!len || !set_len) return -1;
    for(pos = 0; pos < len; pos++) {
        for(set_pos = 0; set_pos < set_len; set_pos++) {
            if(str[pos] == set[set_pos]) return pos;
        }
    }
    return -1;
}

nomask static int *strallcpos(string str, int c)
{
    int pos;
    int * result;

    result = ({});

    if(str && strlen(str)) {
        for(pos = 0; pos < strlen(str); pos++) {
            if(str[pos] == c) {
                result += ({pos});
            }
        }
    }
    return result;
}

nomask static string sprintf(mixed args...) {
    return "/kernel/lib/extra/Sprintf/sprintf"->do_sprintf(args...);
}

