private object global;	/* the global object */

/*
 * NAME:	init_global()
 * DESCRIPTION:	initialize the global object interface
 */
private void init_global()
{
    if (object_name(this_object()) == GLOBAL) {
	global = this_object();
    } else {
	global = ::find_object(GLOBAL);
	if (global == 0) {
	    global = ::compile_object(GLOBAL);
	}
    }
    global->add_object();
}

/*
 * NAME:	set_this_player()
 * DESCRIPTION:	set the current player
 */
static void set_this_player(object player)
{
    global->set_this_player(player);
}

/*
 * NAME:	this_player()
 * DESCRIPTION:	return the current player, or interactive user
 */
static varargs object this_player(int flag)
{
    if (flag) {
	if (this_user()) {
	    return this_user()->query_player();
	}
	return 0;
    }
    return global->query_this_player();
}

/*
 * NAME:	set_living_name()
 * DESCRIPTION:	set the living name of the current object
 */
static void set_living_name(string name)
{
    ARGCHECK(name, set_living_name, 1);

    global->set_living_name(name);
}

/*
 * NAME:	find_player()
 * DESCRIPTION:	find a player by name
 */
static object find_player(string name)
{
    ARGCHECK(name, find_player, 1);

    return global->query_find_player(name);
/*
    return "/kernel/servers/linkstatus"->find_player_by_name(name);
*/
}

/*
 * NAME:	find_living()
 * DESCRIPTION:	find a living object by name
 */
static object find_living(string name)
{
    ARGCHECK(name, find_living, 1);

    return global->query_find_living(name);
}

/*
 * NAME:	set_verb()
 * DESCRIPTION:	set the current verb
 */
private void set_verb(string verb)
{
    global->set_verb(verb);
}

/*
 * NAME:	query_verb()
 * DESCRIPTION:	get the current verb
 */
static string query_verb()
{
    return global->query_verb();
}

/*
 * NAME:	show_wiz_list()
 * DESCRIPTION:	show the wizlist
 */
private void show_wiz_list()
{
    global->show_wiz_list();
}

/*
 * NAME:	del_object()
 * DESCRIPTION:	delete this object
 */
private void del_object()
{
    global->del_object();
}

/*
 * NAME:	add_heart_beat()
 * DESCRIPTION:	add a heart_beat
 */
private void add_heart_beat()
{
    global->add_heart_beat();
}

/*
 * NAME:	del_heart_beat()
 * DESCRIPTION:	delete a heart_beat
 */
private void del_heart_beat()
{
    global->del_heart_beat();
}

/*
 * NAME:	add_call_out()
 * DESCRIPTION:	add a call_out
 */
private void add_call_out()
{
    if (this_object() != global) {
	global->add_call_out();
    }
}

/*
 * NAME:	del_call_out()
 * DESCRIPTION:	delete a call_out
 */
private void del_call_out()
{
    if (this_object() != global) {
	global->del_call_out();
    }
}

static int query_heart_beat(varargs object obj) {
  if(!obj) obj = this_object();
  if (obj != global) {
        return global->query_heart_beat(obj);
  }
}

