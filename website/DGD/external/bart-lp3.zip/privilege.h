# define PRIVILEGED()	(previous_program() == AUTO)
# define KERNEL()       (sscanf(previous_program(),"/kernel/%*s") != 0)

