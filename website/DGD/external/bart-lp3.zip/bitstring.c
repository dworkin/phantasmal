/*
 * provide call level compatibility with Kobra's bitstring implementation.
 */
        
nomask static string and_bitstring( string str1, string str2 )
{
    int pos;
    int max;
    string result;

    result = "";
    if(strlen(str1) > strlen(str2)) max = strlen(str2);
    else max = strlen(str1);
    for(pos = 0; pos < max; pos++) {
        result[pos] = str1[pos] & str2[pos];
    }
    return result;
}

nomask static string or_bitstring( string str1, string str2 )
{
    int pos;
    int max;
    string result;
    result = "";
    if(strlen(str1) > strlen(str2)) max = strlen(str2);
    else max = strlen(str1);
    for(pos = 0; pos < max; pos++) {
        result[pos] = str1[pos] | str2[pos];
    }
    return result;
}

nomask static string xor_bitstring( string str1, string str2 )
{
    int pos;
    int max;
    string result;
    result = "";
    if(strlen(str1) > strlen(str2)) max = strlen(str2);
    else max = strlen(str1);
    for(pos = 0; pos < max; pos++) {
        result[pos] = str1[pos] ^ str2[pos];
    }
    return result;
}

private int *convert_bit_position(int bit)
{

    int bytes, bits;

    bytes = bit /8;
    bits = bit - (8 * bytes);
    switch(bits) {
        case 7 : bits = 128; break;
        case 6 : bits = 64; break;
        case 5 : bits = 32; break;
        case 4 : bits = 16; break;
        case 3 : bits = 8; break;
        case 2 : bits = 4; break;
        case 1 : bits = 2; break;
        default : bits = 1; break;
    }
    return ({bytes, bits});
}

/*
nomask static int test_bit(string str, int bit) {
#define BYTE tmp[0]
#define BIT  tmp[1]
    int *tmp;

    tmp = convert_bit_position(bit);
    return (str[BYTE] & BIT) ? 1 : 0;
}

nomask static string set_bit(string str, int bit) {
    int *tmp;
    tmp = convert_bit_position(bit);
    str[BYTE] |= BIT;
    return str;
}

nomask static string clear_bit(string str, int bit) {
    int *tmp;
    tmp = convert_bit_position(bit);
    str[BYTE] &= BIT;
    return str;
#undef BYTE
#undef BIT
}
*/

nomask static int countbits(string str)
{
    int result, pos;
    for(pos = 8 * strlen(str) - 1;pos >= 0; pos--) {
        if(test_bit(str, pos)) result++;
    }
    return result;
}

