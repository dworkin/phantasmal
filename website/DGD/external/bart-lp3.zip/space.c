/*
 * Code to handle some 'space' related things like the position of
 * this object in the 3d grid.
 */

private int pos_x;
private int pos_y;
private int pos_z;
private int vec_x;
private int vec_y;
private int vec_z;

void set_space_pos_x(int i) {
    pos_x = i;
}

void set_space_pos_y(int i) {
    pos_y = i;
}

void set_space_pos_z(int i) {
    pos_z = i;
}

int query_space_pos_x() {
    return pos_x;
}

int query_space_pos_y() {
    return pos_y;
}

int query_space_pos_z() {
    return pos_z;
}

void set_space_vec_x(int i) {
    vec_x = i;
}

void set_space_vec_y(int i) {
    vec_y = i;
}

void set_space_vec_z(int i) {
    vec_z = i;
}

int query_space_vec_x() {
    return vec_x;
}

int query_space_vec_y() {
    return vec_y;
}

int query_space_vec_z() {
    return vec_z;
}

void do_spacial_move(int ticks) {
    while(ticks) {
        pos_x += vec_x;
        pos_y += vec_y;
        pos_z += vec_z;
    }
}

int * query_space_position() {
    return ({ pos_x, pos_y, pos_z });
}

int * query_space_vector() {
    return ({ vec_x, vec_y, vec_z });
}

