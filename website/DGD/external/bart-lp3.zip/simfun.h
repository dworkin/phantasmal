static object clone_object(string file);
static object find_object(string file);
static int get_exec_cost();
static varargs mixed *
filter_objects(mixed *arr, string func, object obj, mixed arg);
static varargs string file_name(object obj);
static varargs string function_exists(string func, object obj);
static int intp(mixed value);
static int floatp(mixed value);
static int stringp(mixed value);
static int objectp(mixed value);
static int arrayp(mixed value);
static int mappingp(mixed value);
static int pointerp(mixed value);
static varargs void add_worth(int worth, object obj);
static varargs void wizlist(string name);
static int transfer(mixed obstr, mixed tostr);
static varargs object present(mixed item, object obj);
static void destruct(object obj);
static string query_host_name();
static string query_load_average();
static void shutdown();
static string version();
#ifdef MUDZ
static varargs string create_wizard(string wizard, string domain);
#endif
static varargs string crypt(string passwd, string salt);
static void notify_fail(string mesg);
static varargs mixed *status(object obj);
static mixed *call_trace();

# define INIT_SIMFUN()
