# include <krn.h>
# include <kernel/kernel.h>
# include <kernel/user.h>

# include <telnet.h>
# include <config.h>


static int	suspended, shutdown;
string welcome_msg, shutdown_msg, suspended_msg;

void upgraded (varargs int clone);

static void create (varargs int clone) 
{
	if (clone) {
		error("Can't clone TelnetD!");
	}
	upgraded();
}

void upgraded (varargs int clone) 
{
	string file;

	if (!SYSTEM())
		return;
	if (!find_object(USER)) { compile_object(USER); }

	file = read_file(WELCOME_MSG);
	if (!file)
		error("Can't read "+WELCOME_MSG);
	welcome_msg = file;

	file = read_file(SHUTDOWN_MSG);
	if (!file)
		error("Can't read "+SHUTDOWN_MSG);
	shutdown_msg = file;

	file = read_file(SUSPENDED_MSG);
	if (!file)
		error("Can't read "+SUSPENDED_MSG);
	suspended_msg = file;

}

void suspend_input (int shutdownp) 
{
	if (!SYSTEM() && !KERNEL())
		return;

	if (suspended)
/*
 *		LOGD->write_syslog("Suspended again without release!", LOG_ERR);
 */
		write_file(LOG_DIR+"/log_err", "Suspended again without release");
	suspended = 1;
	if (shutdownp)
		shutdown = 1;
}

void release_input (void)
{
	if (!SYSTEM() && !KERNEL())
		return;

	if (!suspended)
/*
 *		LOGD->write_syslog("Released without suspend!", LOG_ERR);
 */
		write_file(LOG_DIR+"/log_err", "Released without suspend.");
	suspended = 0;
}

object select (string str) 
{
	if (!SYSTEM() && !KERNEL())
		return nil;

	return clone_object(USER);
}

int query_timeout (object connection) 
{
	if (!SYSTEM() && !KERNEL())
		return -1;

	if (suspended || shutdown)
		return -1;

	return DEFAULT_TIMEOUT;
}

string query_banner (object connection)
{
	if (!SYSTEM() && !KERNEL())
		return nil;
	if (shutdown)
		return shutdown_msg;
	if (suspended)
		return suspended_msg;

	return welcome_msg+LOGIN_PROMPT;

}


