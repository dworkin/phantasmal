# include <krn.h>
# include <kernel/kernel.h>
# include <kernel/access.h>
# include <kernel/rsrc.h>
# include <kernel/user.h>
# include <config.h>

static int create(varargs int clone) {
	object accessd, driver, rsrcd, telnetd;
	string *users;
	int i;
	write_file("/log.txt", "Successful initd.c test\n");

	accessd = find_object(ACCESSD);
	driver  = find_object(DRIVER);
	rsrcd   = find_object(RSRCD);
    rsrcd->rsrc_incr("System", "filequota", nil,
        driver->file_size(LIBRARY_DIR+"/secure", TRUE)	+ 
		driver->file_size(LIBRARY_DIR+"/kernel", TRUE)	+
        driver->file_size(OBJECT_DIR +"/secure", TRUE)	+
        driver->file_size(OBJECT_DIR +"/kernel", TRUE)	+
        driver->file_size(SYSTEM_DIR +"/secure", TRUE)	+
		driver->file_size(SYSTEM_DIR +"/kernel", TRUE)	+
        driver->file_size(  DATA_DIR, TRUE) 			-
		driver->file_size(  DATA_DIR +"/common", TRUE)	+
		driver->file_size(COMMAND_DIR,TRUE) +
		driver->file_size(WORLD_DIR+"/object", TRUE) +
		driver->file_size(WORLD_DIR+"/room",   TRUE));

	rsrcd->rsrc_incr(nil, "filequota", nil,
		driver->file_size(    LOG_DIR, TRUE));
	rsrcd->add_owner("common");
	rsrcd->rsrc_incr("common", "filequota", nil,
		driver->file_size(LIBRARY_DIR+"/common", TRUE)	+
        driver->file_size(OBJECT_DIR +"/common", TRUE)	+
        driver->file_size(SYSTEM_DIR +"/common", TRUE)	+
		driver->file_size(  DATA_DIR +"/common", TRUE)); 
	/*
	 * If more subDirs are added to the MAIN 4 above, then an
	 * owner will need to be added, AND resources allocated.
	 * AS WELL the creator() function in driver.c will need to 
	 * be notified of it, so that it can return the proper 'creator'
	 * 		-- If you don't understand that, don't do it. Zamadhi.
	 */

    /* initialize users resources in /world/area/<user> */
    users = (accessd->query_users() - ({ "System" })) | ({ "admin" });
    for (i = sizeof(users); --i >= 0; ) {
	/*
	 *	Already added as owners in the driver's initialize. So skip it.
	 *		rsrcd->add_owner(users[i]);
	 */
		rsrcd->rsrc_incr(users[i], "filequota", nil,
			driver->file_size(WORLD_DIR + "/area/" + users[i], TRUE));
    }

	if (!find_object(TELNETD)) { compile_object(TELNETD); }

	telnetd = find_object(TELNETD);
	USERD->set_telnet_manager(0, telnetd);
}
