# define WELCOME_MSG     "/data/text/welcome.ascii"
# define SHUTDOWN_MSG    "/data/text/shutdown.msg"
# define SUSPENDED_MSG   "/data/text/suspended.msg"
# define LOGIN_PROMPT    "What is thy name? \x10"
