# define USR		"/home"	/* default user directory */

# undef SYS_PERSISTENT		/* off by default */

# define CALLOUTRSRC	FALSE	/* don't have callouts as a resource */

# define INITD			"/system/secure/initd"
# define TELNETD		"/system/secure/telnetd"
# define USER			"/object/secure/user"
# define WIZTOOL		"/object/secure/wiztool"
