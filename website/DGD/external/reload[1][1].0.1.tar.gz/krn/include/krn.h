/* This is a little confusing since we have defines below of DIR_OBJ, etc
 * But it's needed for various sscanf's
 */
#define DATA_DIR		"/data"		/* Used in accessd.c				*/
#define KERNEL_DIR		"/kernel"	/* Used in driver.c runtime_error()	*/
#define LIBRARY_DIR		"/inherit"	/* Not Used Yet						*/
#define OBJECT_DIR		"/object"	/* Used in inherit/wiztool.c		*/
#define SYSTEM_DIR		"/system"	/* Used in driver.c _initialize()	*/

#define COMMAND_DIR		"/command"
#define LOG_DIR			"/log"
#define WORLD_DIR		"/world"
/* For sake of completeness, whether this will even be used or not, whatever */
#define DOC_DIR			"/doc"
#define INCLUDE_DIR		"/include"


/* We'll leave this kernel in the subdir of include */
#define INCLUDE(f)  sscanf(f, "/include/kernel/%*s") != 0
#define IS_KRNL(f)  sscanf(f, "/%*s/kernel/") != 0	/* Should == KERNEL_DIR */
/* This one's only found in auto.c's call_out() I believe
 * If rsrc.c && rsrcd.c are moved this define should reflect that.
 */
#define DIR_RSRC(f) sscanf(f, "/%*s/kernel/rsrc") != 0

#define DIR_DAT(f)  sscanf(f, "%*s/data/") != 0		/* Should == DATA_DIR	*/
#define DIR_LIB(f)  sscanf(f, "%*s/inherit/") != 0	/* Should == LIBRARY_DIR*/
#define DIR_OBJ(f)  sscanf(f, "%*s/object/") != 0	/* Should == OBJECT_DIR */

#define HAS_ACCESS( Who, Path, Type) ::find_object(ACCESSD)->access(Who, Path, Type)
#define HAS_READ_ACCESS( Who, Path ) ::find_object(ACCESSD)->access(Who, Path, READ_ACCESS)
#define HAS_WRITE_ACCESS( Who, Path ) ::find_object(ACCESSD)->access(Who, Path, WRITE_ACCESS)
