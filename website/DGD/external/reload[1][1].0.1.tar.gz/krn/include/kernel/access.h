# define ACCESSD	"/system/kernel/accessd"
# define API_ACCESS	"/inherit/kernel/api/access"
# define ACCESSDATA	"/data/kernel/access.data"

# define READ_ACCESS	1	/* read access only */
# define WRITE_ACCESS	2	/* read + write */
# define FULL_ACCESS	3	/* read + write + access granting */
