# define OBJREGD	"/system/kernel/objregd"
# define API_OBJREG	"/inherit/kernel/api/objreg"
