#include <config.h>

# define DRIVER		"/system/kernel/driver"
# define AUTO		"/inherit/kernel/auto"

/*
 * privilege levels
 */
# define KERNEL()	sscanf(previous_program(), "/%*s/kernel/")
# define SYSTEM()	sscanf(previous_program(), "/%*s/secure/")
