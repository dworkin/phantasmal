MudBuild for Merantha Mudlib

The MudBuild program was developed to ease the production of basic room files for the Merantha Mudlib in a standard format. It will also make and compile basic NPC's, Armour, Objects, and Weapons. Files can then be saved in both "raw data" and ".c" Unix compatable files.

It was not developed to be able to program every variation of room i.e. shops, bars etc.

Large area's of rooms can be produced in a short time in a basic 'mass production' format i.e. a forest or a city. Local changes to special rooms can then be made with your favourite ".c" editor.

What is the Merentha Mudlib?
The Merentha Mudlib is a LPC Mudlib created by Petrarch of Merentha, aka Peter Sadlon. 

Copyright

All parts of the program "MudBuild", its idea and any associated documentation are Copyright Rama of Merentha aka Paul Ledbrook. rama@m-u-d.co.uk

All References to "Merantha Mudlib", its variations and code is copyright Petrarch of Merentha, aka Peter Sadlon .
Full details can be found at http://www.merentha.com/mublib/

This program is released under E-mailwarz - if you would like to use the program, send me an E-mail and I will inform you when I release a new version.

All comments/ bugs etc please send to mudbuild@m-u-d.co.uk
